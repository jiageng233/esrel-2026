"""BNP reliability assessment demo for cryogenic products (paper-aligned).

This script is written to match (and slightly refine) the following abstract:

Abstract (refined):
  Products operating in cryogenic environments face reliability assessment challenges
  characterized by small sample sizes, high uncertainty, and heterogeneous failure
  mechanisms. Traditional reliability methods often rely on large-sample assumptions
  and pre-specified lifetime distributions, which can be fragile when data are scarce
  and failure modes are diverse. To address these limitations, we introduce a Bayesian
  nonparametric (BNP) reliability assessment framework that learns failure-mode
  structure directly from data without fixing the number of modes a priori. The
  framework also supports lightweight fusion of multi-source information (limited
  test data, historical data, and expert knowledge) via pseudo-sample augmentation.
  We highlight the use of Dirichlet Process Mixture Models (DPMM) for failure-mode
  discovery from heterogeneous covariates and the use of Gaussian Processes (GP) for
  modeling degradation trajectories under cryogenic conditions, with uncertainty-aware
  remaining useful life (RUL) estimation. Accuracy and robustness under small-sample
  conditions are demonstrated through simulation and a case-style analysis.

What this file provides
- DPMM (bnpy) learns failure modes from covariates.
- Nonparametric survival analysis via Kaplan–Meier handles right-censoring.
- Bootstrap bands quantify uncertainty for R(t) without assuming a lifetime distribution.
- GP degradation model (gpytorch) estimates RUL with credible intervals.
- Optional multi-source fusion via pseudo-sample augmentation (default off).

Outputs
- Figures and CSV summaries under --outdir (default: results/paper_demo)

Run
  python bnp_cryogenic_paper_demo.py --quick

Notes
- Requires bnpy, numpy, pandas, matplotlib.
- GP part requires torch + gpytorch.
"""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

# Ensure local imports work even when executed via wrappers (e.g., VS Code runpy).
_REPO_ROOT = Path(__file__).resolve().parent
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

import numpy as np
import pandas as pd

import warnings

try:
    from sklearn.exceptions import ConvergenceWarning
except Exception:  # pragma: no cover
    ConvergenceWarning = Warning  # type: ignore[misc,assignment]

from sklearn.mixture import BayesianGaussianMixture
from sklearn.mixture import GaussianMixture
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel, DotProduct, Matern, RBF, WhiteKernel
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import Ridge
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score



@dataclass
class Config:
    seed: int = 0
    n_failure_samples: int = 200
    include_censored: bool = True

    # DPMM
    K_init: int = 10
    nLap: int = 120

    # Kaplan–Meier grid + bootstrap
    n_time_grid: int = 120
    bootstrap: int = 200
    ci: float = 0.90

    # Degradation/GP
    n_degradation_units: int = 25
    max_cycles: int = 60
    gp_threshold: float = 20.0
    gp_max_future: int = 120
    gp_ci: float = 0.90
    gp_mc_paths: int = 300
    gp_obs_ratio: float = 0.70
    gp_n_restarts: int = 10
    gp_kernel_family: str = "matern+rbf"  # options: matern | rbf | matern+rbf | matern+rbf+periodic
    gp_model_selection: str = "lml"  # options: lml | holdout
    gp_holdout_frac: float = 0.25
    gp_holdout_min_points: int = 3
    gp_holdout_max_points: int = 10
    gp_holdout_min_total: int = 8

    # Pooled coupling (global vs mode-expert GP)
    pooled_loo_by_unit: bool = True
    pooled_unit_cv_folds: int = 5
    pooled_mode_min_units: int = 5
    mode_infer_max_points: int = 20
    gp_bound_hit_eps: float = 1e-3

    # Multi-source fusion (pseudo-samples)
    history_strength: int = 0
    expert_strength: int = 0

    # NASA C-MAPSS validation
    nasa_max_future: int = 400
    nasa_gp_ci: float = 0.90
    nasa_gp_mc_paths: int = 0  # 0 => use mean crossing only

    # NASA supervised RUL benchmark
    nasa_window: int = 20
    nasa_step: int = 5


def _make_unit_folds(unit_ids: list[int], n_folds: int, seed: int) -> list[list[int]]:
    unit_ids = [int(u) for u in unit_ids]
    if len(unit_ids) == 0:
        return []
    if n_folds <= 1 or len(unit_ids) == 1:
        return [unit_ids]
    n_folds = int(min(n_folds, len(unit_ids)))
    rng = np.random.default_rng(int(seed))
    perm = unit_ids.copy()
    rng.shuffle(perm)
    folds: list[list[int]] = [[] for _ in range(n_folds)]
    for i, u in enumerate(perm):
        folds[int(i % n_folds)].append(int(u))
    folds = [f for f in folds if len(f) > 0]
    return folds


def _build_unit_mode_features(
    degradation_df: pd.DataFrame,
    *,
    unit_ids: list[int],
    prefix_cycle_by_unit: Optional[Dict[int, int]] = None,
    max_points: int = 20,
) -> pd.DataFrame:
    rows = []
    sub = degradation_df[degradation_df["equipment_id"].isin([int(u) for u in unit_ids])]
    for equipment_id, g in sub.sort_values(["equipment_id", "cycle"]).groupby("equipment_id"):
        g = g.sort_values("cycle")
        if prefix_cycle_by_unit is not None:
            cmax = prefix_cycle_by_unit.get(int(equipment_id), None)
            if cmax is not None:
                g = g[g["cycle"] <= int(cmax)]
        if len(g) < 3:
            continue
        temp = float(g["temperature"].mean()) if "temperature" in g.columns else 0.0
        reuse = float(g["reuse_count"].iloc[0]) if "reuse_count" in g.columns else 0.0
        y = g["performance"].to_numpy(dtype=float)
        x = g["cycle"].to_numpy(dtype=float)
        n0 = int(min(len(x), max(5, int(max_points))))
        if n0 >= 2:
            x0 = x[:n0] - float(np.mean(x[:n0]))
            denom = float(np.sum(x0**2))
            slope = float(np.sum(x0 * (y[:n0] - float(np.mean(y[:n0])))) / denom) if denom > 1e-12 else 0.0
        else:
            slope = 0.0
        rows.append({"equipment_id": int(equipment_id), "f_temp": temp, "f_reuse": reuse, "f_slope": slope})
    return pd.DataFrame(rows).sort_values("equipment_id")


NASA_COLUMNS = [
    "unit_id",
    "cycle",
    "op_setting_1",
    "op_setting_2",
    "op_setting_3",
    *[f"sensor_{i}" for i in range(1, 22)],
]

# A commonly used subset of informative sensors for FD001.
NASA_KEY_SENSORS = ["sensor_2", "sensor_3", "sensor_4", "sensor_7", "sensor_11", "sensor_12", "sensor_15", "sensor_20"]


# ----------------------------- Utilities -----------------------------

def _set_seed(seed: int) -> None:
    np.random.seed(int(seed))


def _try_import_matplotlib():
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        return plt
    except Exception as e:
        print("[demo] matplotlib unavailable; skipping plots")
        print(f"[demo] matplotlib import error: {e}")
        return None


def _safe_read_cmapss_txt(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep=r"\s+", header=None, names=NASA_COLUMNS)


def _build_nasa_health_index(train_df: pd.DataFrame, test_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, float]:
    """Construct a simple degradation index from sensors (FD001-friendly).

    Returns normalized train/test with added columns:
      - sensor_mean, sensor_max, cycle_ratio, degradation
    and a global failure threshold inferred from train end-of-life degradation.

    Note: Many C-MAPSS sensors are not monotone in the same direction.
    This demo uses a pragmatic weighted index similar to the companion
    `examples/reliability_assessment.py` script.
    """

    sensors = [s for s in NASA_KEY_SENSORS if s in train_df.columns]
    if not sensors:
        raise ValueError("No NASA sensors found in input")

    train = train_df.copy()
    test = test_df.copy()

    # Min-max normalize sensors based on training set to avoid leakage
    for s in sensors:
        lo = float(train[s].min())
        hi = float(train[s].max())
        scale = (hi - lo) if hi != lo else 1e-8
        train[s] = (train[s] - lo) / scale
        test[s] = (test[s] - lo) / scale

    train["sensor_mean"] = train[sensors].mean(axis=1)
    train["sensor_max"] = train[sensors].max(axis=1)
    test["sensor_mean"] = test[sensors].mean(axis=1)
    test["sensor_max"] = test[sensors].max(axis=1)

    # Add cycle progress (train uses true EOL; test uses observed max cycle only).
    if "fail_cycle" in train.columns:
        train["cycle_ratio"] = train["cycle"] / train["fail_cycle"].replace(0, np.nan)
    else:
        train_last = train.groupby("unit_id")["cycle"].transform("max")
        train["cycle_ratio"] = train["cycle"] / train_last.replace(0, np.nan)

    test_last = test.groupby("unit_id")["cycle"].transform("max")
    test["cycle_ratio"] = test["cycle"] / test_last.replace(0, np.nan)

    train["cycle_ratio"] = train["cycle_ratio"].fillna(0.0).clip(0.0, 1.0)
    test["cycle_ratio"] = test["cycle_ratio"].fillna(0.0).clip(0.0, 1.0)

    # Degradation index (higher => worse). Keep this sensor-based to reduce
    # train/test mismatch (test trajectories are truncated before failure).
    train["degradation"] = 0.7 * train["sensor_mean"] + 0.3 * train["sensor_max"]
    test["degradation"] = 0.7 * test["sensor_mean"] + 0.3 * test["sensor_max"]

    # Define threshold from train end-of-life degradation
    if "fail_cycle" in train.columns:
        eol = train[train["cycle"] == train["fail_cycle"]]
        eol_deg = eol["degradation"].to_numpy(dtype=float)
    else:
        eol_deg = train.groupby("unit_id")["degradation"].last().to_numpy(dtype=float)

    base = float(np.mean(eol_deg)) if eol_deg.size else float(np.mean(train["degradation"].to_numpy(dtype=float)))
    threshold = 0.9 * base  # slightly relaxed global threshold
    return train, test, threshold


def _fit_unit_gp_cycle_to_perf(cycle: np.ndarray, perf: np.ndarray, seed: int) -> GaussianProcessRegressor:
    cycle = np.asarray(cycle, dtype=float).reshape(-1, 1)
    perf = np.asarray(perf, dtype=float).reshape(-1)
    mean, std = _standardize_fit(cycle)
    Xz = _standardize_apply(cycle, mean, std)

    # Use a small kernel set and select the best by log-marginal-likelihood.
    # This improves robustness across different trajectory shapes.
    k_matern = (
        DotProduct(sigma_0=1.0)
        + ConstantKernel(1.0, (1e-2, 1e2)) * Matern(length_scale=1.0, nu=2.5)
        + WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-4, 1e2))
    )
    k_rbf = (
        DotProduct(sigma_0=1.0)
        + ConstantKernel(1.0, (1e-2, 1e2)) * RBF(length_scale=1.0)
        + WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-4, 1e2))
    )

    best_gpr = None
    best_lml = -np.inf
    for ker in (k_matern, k_rbf):
        gpr_try = GaussianProcessRegressor(
            kernel=ker,
            alpha=0.0,
            normalize_y=True,
            random_state=int(seed),
            n_restarts_optimizer=2,
        )
        gpr_try.fit(Xz, perf)
        try:
            lml = float(gpr_try.log_marginal_likelihood())
        except Exception:
            lml = -np.inf
        if lml > best_lml:
            best_lml = lml
            best_gpr = gpr_try

    gpr = best_gpr if best_gpr is not None else gpr_try
    gpr._x_mean = mean  # type: ignore[attr-defined]
    gpr._x_std = std  # type: ignore[attr-defined]
    return gpr


def _predict_unit_rul_from_gp(
    gpr: GaussianProcessRegressor,
    last_cycle: int,
    threshold: float,
    max_future: int,
) -> int:
    horizon = int(max_future)
    future = np.arange(int(last_cycle), int(last_cycle) + horizon + 1, dtype=float).reshape(-1, 1)
    mean = getattr(gpr, "_x_mean")
    std = getattr(gpr, "_x_std")
    Xz = _standardize_apply(future, mean, std)
    mu = gpr.predict(Xz)
    # Here `perf` is a degradation index (higher => worse), so failure when mu >= threshold.
    hit = np.where(mu >= float(threshold))[0]
    if hit.size == 0:
        return horizon
    # Remaining cycles until threshold crossing
    return int(future[int(hit[0])][0] - float(last_cycle))


def run_nasa_cmapss_validation(cfg: Config, nasa_dir: Path, subset: str, outdir: Path) -> None:
    subset = str(subset).upper()
    train_path = nasa_dir / f"train_{subset}.txt"
    test_path = nasa_dir / f"test_{subset}.txt"
    rul_path = nasa_dir / f"RUL_{subset}.txt"

    if not (train_path.exists() and test_path.exists() and rul_path.exists()):
        raise FileNotFoundError(f"Missing NASA files for {subset} under {nasa_dir}")

    train_df = _safe_read_cmapss_txt(train_path)
    test_df = _safe_read_cmapss_txt(test_path)
    rul_df = pd.read_csv(rul_path, header=None, names=["true_rul"])
    rul_df["unit_id"] = np.arange(1, len(rul_df) + 1)

    # Add per-unit failure cycle for training (needed for supervised RUL labels)
    train_fail = train_df.groupby("unit_id")["cycle"].max().reset_index(name="fail_cycle")
    train_df = train_df.merge(train_fail, on="unit_id", how="left")

    train_df, test_df, perf_threshold = _build_nasa_health_index(train_df, test_df)

    # Optional: unit-level GP interval validation on NASA training units.
    # This evaluates the paper's main claim (interval calibration) on a public dataset.
    if int(getattr(cfg, "nasa_gp_mc_paths", 0)) > 0:
        out_gp = outdir / "nasa_gp_intervals_train_units"
        out_gp.mkdir(parents=True, exist_ok=True)

        # Use the same GP+conformal machinery as the simulation pipeline by mapping
        # NASA degradation (higher=worse) to performance = -degradation (lower=worse).
        cfg_gp = replace(
            cfg,
            gp_ci=float(getattr(cfg, "nasa_gp_ci", cfg.gp_ci)),
            gp_mc_paths=int(getattr(cfg, "nasa_gp_mc_paths", 200)),
            gp_max_future=int(getattr(cfg, "nasa_max_future", cfg.gp_max_future)),
            gp_threshold=float(-perf_threshold),
        )

        ratios = (0.5, 0.7, 0.9)
        summary_rows = []
        for r in ratios:
            rows = []
            for unit_id, g in train_df.sort_values(["unit_id", "cycle"]).groupby("unit_id"):
                g = g.sort_values("cycle")
                fail_cycle = int(g["cycle"].max())
                if fail_cycle <= 5:
                    continue

                obs_cycle = max(2, int(np.floor(float(r) * float(fail_cycle))))
                true_rul = float(fail_cycle - obs_cycle)

                sub = g[g["cycle"] <= obs_cycle]
                if len(sub) < 5:
                    continue

                equip_obs = pd.DataFrame(
                    {
                        "cycle": sub["cycle"].to_numpy(dtype=int),
                        "performance": (-sub["degradation"]).to_numpy(dtype=float),
                    }
                )

                pred = fit_gp_and_rul_from_df(equip_obs, equipment_id=int(unit_id), cfg=cfg_gp)
                lo = float(pred["rul_lower"])
                hi = float(pred["rul_upper"])
                med = float(pred.get("rul_median", pred.get("rul_mean", np.nan)))

                rows.append(
                    {
                        "unit_id": int(unit_id),
                        "fail_cycle": int(fail_cycle),
                        "obs_cycle": int(obs_cycle),
                        "obs_ratio": float(r),
                        "true_rul": float(true_rul),
                        "pred_rul_median": med,
                        "pred_rul_lower": lo,
                        "pred_rul_upper": hi,
                        "covered": bool((lo <= true_rul) and (true_rul <= hi)),
                        "interval_width": float(hi - lo),
                        "gp_convergence_warning_final": float(pred.get("gp_convergence_warning_final", np.nan)),
                    }
                )

            per_unit = pd.DataFrame(rows).sort_values("unit_id")
            if len(per_unit) == 0:
                continue

            # CQR-style conformalization of the interval itself (LOO across units)
            true_all = per_unit["true_rul"].to_numpy(dtype=float)
            raw_lo = per_unit["pred_rul_lower"].to_numpy(dtype=float)
            raw_hi = per_unit["pred_rul_upper"].to_numpy(dtype=float)
            score_all = np.maximum.reduce([raw_lo - true_all, true_all - raw_hi, np.zeros_like(true_all)])
            n = int(len(per_unit))
            q_int_loo = np.full(n, np.nan, dtype=float)
            for i in range(n):
                others = np.delete(score_all, i)
                q_int_loo[i] = _conformal_q_from_abs_errors(others, ci=float(cfg_gp.gp_ci))
            lo_int = raw_lo - q_int_loo
            hi_int = raw_hi + q_int_loo

            per_unit["pred_rul_lower_conformal_int"] = lo_int
            per_unit["pred_rul_upper_conformal_int"] = hi_int
            per_unit["covered_conformal_int"] = (lo_int <= true_all) & (true_all <= hi_int)
            per_unit["interval_width_conformal_int"] = hi_int - lo_int

            per_unit.to_csv(out_gp / f"nasa_{subset}_gp_intervals_train_units_ratio_{r:.1f}.csv", index=False)

            summary_rows.append(
                {
                    "subset": subset,
                    "obs_ratio": float(r),
                    "n_units": int(len(per_unit)),
                    "coverage_raw": float(np.mean(per_unit["covered"].to_numpy(dtype=float))),
                    "avg_width_raw": float(np.mean(per_unit["interval_width"].to_numpy(dtype=float))),
                    "coverage_conformal_int": float(np.mean(per_unit["covered_conformal_int"].to_numpy(dtype=float))),
                    "avg_width_conformal_int": float(np.mean(per_unit["interval_width_conformal_int"].to_numpy(dtype=float))),
                    "ci": float(cfg_gp.gp_ci),
                    "gp_warning_rate_final": float(np.nanmean(per_unit["gp_convergence_warning_final"].to_numpy(dtype=float)))
                    if "gp_convergence_warning_final" in per_unit.columns
                    else np.nan,
                }
            )

        if summary_rows:
            pd.DataFrame(summary_rows).sort_values(["subset", "obs_ratio"]).to_csv(
                out_gp / f"nasa_{subset}_gp_intervals_train_units_summary.csv",
                index=False,
            )

    # ------------------- Supervised prefix->RUL benchmark -------------------
    # Build training samples by taking prefixes of each unit trajectory.
    window = int(cfg.nasa_window)
    step = int(cfg.nasa_step)

    def _window_features(cycles: np.ndarray, vals: np.ndarray, end_idx: int) -> Tuple[float, float, float]:
        start = max(0, int(end_idx) - window + 1)
        x = cycles[start : end_idx + 1].astype(float)
        y = vals[start : end_idx + 1].astype(float)
        mean = float(np.mean(y)) if y.size else 0.0
        std = float(np.std(y)) if y.size else 0.0
        if y.size >= 2:
            x0 = x - x.mean()
            denom = float(np.sum(x0**2))
            slope = float(np.sum(x0 * (y - y.mean())) / denom) if denom > 1e-12 else 0.0
        else:
            slope = 0.0
        return mean, std, slope

    X_list = []
    y_list = []
    for unit_id, g in train_df.sort_values(["unit_id", "cycle"]).groupby("unit_id"):
        cycles = g["cycle"].to_numpy(dtype=float)
        degr = g["degradation"].to_numpy(dtype=float)
        fail_cycle = float(g["fail_cycle"].iloc[-1])

        # sample multiple time points along the trajectory
        for idx in range(0, len(cycles), step):
            c = float(cycles[idx])
            rul = fail_cycle - c
            if rul < 0:
                continue
            mean_w, std_w, slope_w = _window_features(cycles, degr, idx)
            X_list.append([c, float(degr[idx]), mean_w, std_w, slope_w])
            y_list.append(float(rul))

    X_train = np.asarray(X_list, dtype=float)
    y_train = np.asarray(y_list, dtype=float)

    models = {
        "ridge": Ridge(alpha=10.0, random_state=int(cfg.seed)),
        "gbrt": GradientBoostingRegressor(random_state=int(cfg.seed)),
        "rf": RandomForestRegressor(
            n_estimators=500,
            max_depth=None,
            min_samples_leaf=2,
            random_state=int(cfg.seed),
            n_jobs=-1,
        ),
    }

    # Precompute per-unit last-step features for test set once
    test_last = test_df.groupby("unit_id")["cycle"].max().reset_index(name="last_cycle")
    test_last = test_last.merge(rul_df, on="unit_id", how="left")
    test_feat_rows = []
    for _, row in test_last.iterrows():
        unit_id = int(row["unit_id"])
        last_cycle = int(row["last_cycle"])
        true_rul = float(row["true_rul"]) if not pd.isna(row["true_rul"]) else np.nan
        unit_ts = test_df[test_df["unit_id"] == unit_id].sort_values("cycle")
        cycles = unit_ts["cycle"].to_numpy(dtype=float)
        degr = unit_ts["degradation"].to_numpy(dtype=float)
        idx = int(len(cycles) - 1)
        mean_w, std_w, slope_w = _window_features(cycles, degr, idx)
        test_feat_rows.append(
            {
                "unit_id": unit_id,
                "last_cycle": last_cycle,
                "true_rul": true_rul,
                "x0": float(last_cycle),
                "x1": float(degr[idx]),
                "x2": float(mean_w),
                "x3": float(std_w),
                "x4": float(slope_w),
            }
        )
    test_feat = pd.DataFrame(test_feat_rows).sort_values("unit_id")
    X_test = test_feat[["x0", "x1", "x2", "x3", "x4"]].to_numpy(dtype=float)

    metrics_rows = []
    for model_name, model in models.items():
        model.fit(X_train, y_train)
        pred = model.predict(X_test).astype(float)
        pred = np.clip(pred, 0.0, float(cfg.nasa_max_future))

        pred_df = test_feat[["unit_id", "last_cycle", "true_rul"]].copy()
        pred_df["pred_rul"] = pred

        valid = pred_df[~pred_df["true_rul"].isna()].copy()
        err = valid["pred_rul"].to_numpy(dtype=float) - valid["true_rul"].to_numpy(dtype=float)
        mae = float(np.mean(np.abs(err)))
        rmse = float(np.sqrt(np.mean(err**2)))

        metrics_rows.append(
            {
                "subset": subset,
                "model": model_name,
                "n_units": int(len(valid)),
                "mae": mae,
                "rmse": rmse,
                "perf_threshold": float(perf_threshold),
                "max_future": int(cfg.nasa_max_future),
                "window": int(window),
                "step": int(step),
            }
        )

        pred_df.to_csv(outdir / f"nasa_{subset}_rul_predictions_{model_name}.csv", index=False)

        plt = _try_import_matplotlib()
        if plt is not None:
            fig, ax = plt.subplots(figsize=(6.2, 6.0))
            ax.scatter(valid["true_rul"], valid["pred_rul"], s=18, alpha=0.6)
            lim = max(float(valid[["true_rul", "pred_rul"]].max().max()), 1.0)
            ax.plot([0, lim], [0, lim], "k--", linewidth=1.5)
            ax.set_xlabel("True RUL")
            ax.set_ylabel("Predicted RUL")
            ax.set_title(f"NASA {subset} ({model_name}): MAE={mae:.1f}, RMSE={rmse:.1f}")
            ax.grid(True, alpha=0.25)
            fig.tight_layout()
            fig.savefig(outdir / f"nasa_{subset}_pred_vs_true_{model_name}.png", dpi=160)
            plt.close(fig)

    metrics = pd.DataFrame(metrics_rows).sort_values(["subset", "model"])
    metrics.to_csv(outdir / f"nasa_{subset}_metrics.csv", index=False)

    # Also fit a DP mixture to failure cycles from training data and output reliability curve
    fail_cycle = train_df.groupby("unit_id")["cycle"].max().to_numpy(dtype=float).reshape(-1, 1)
    dp = BayesianGaussianMixture(
        n_components=10,
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        max_iter=800,
        random_state=int(cfg.seed),
        init_params="kmeans",
        reg_covar=1e-6,
    )
    dp.fit(fail_cycle)
    weights = dp.weights_.copy()
    means = dp.means_.reshape(-1)
    covs = dp.covariances_.reshape(-1)
    stds = np.sqrt(np.maximum(covs, 1e-10))

    # Reliability R(t) = sum_k w_k * (1 - Phi((t-mu)/sigma))
    from math import erf, sqrt

    def _phi(z: np.ndarray) -> np.ndarray:
        return 0.5 * (1.0 + np.vectorize(erf)(z / sqrt(2.0)))

    t_grid = np.linspace(0.0, float(np.max(fail_cycle)) * 1.2, 200)
    z = (t_grid[:, None] - means[None, :]) / stds[None, :]
    R = (weights[None, :] * (1.0 - _phi(z))).sum(axis=1)
    pd.DataFrame({"t": t_grid, "R": R}).to_csv(outdir / f"nasa_{subset}_reliability_curve.csv", index=False)

    plt = _try_import_matplotlib()
    if plt is not None:
        # Reliability curve
        fig, ax = plt.subplots(figsize=(7.2, 5.0))
        ax.plot(t_grid, R, linewidth=2.0)
        ax.set_xlabel("cycles")
        ax.set_ylabel("Reliability R(t)")
        ax.set_title(f"NASA {subset}: DP mixture reliability from failure cycles")
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(outdir / f"nasa_{subset}_reliability.png", dpi=160)
        plt.close(fig)


def run_nasa_cmapss_benchmark(cfg: Config, nasa_dir: Path, outdir: Path, subsets: Optional[Iterable[str]] = None) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    if subsets is None:
        subsets = ["FD001", "FD002", "FD003", "FD004"]

    all_metrics = []
    for subset in subsets:
        subset = str(subset).upper()
        subdir = outdir / subset
        subdir.mkdir(parents=True, exist_ok=True)
        run_nasa_cmapss_validation(cfg=cfg, nasa_dir=nasa_dir, subset=subset, outdir=subdir)

        metrics_path = subdir / f"nasa_{subset}_metrics.csv"
        m = pd.read_csv(metrics_path)
        all_metrics.append(m)

    summary = pd.concat(all_metrics, axis=0, ignore_index=True)
    summary.to_csv(outdir / "nasa_benchmark_summary.csv", index=False)

    plt = _try_import_matplotlib()
    if plt is not None:
        # Simple RMSE comparison plot
        fig, ax = plt.subplots(figsize=(8.0, 4.6))
        order = ["FD001", "FD002", "FD003", "FD004"]
        models = ["ridge", "gbrt", "rf"]
        x = np.arange(len(order), dtype=float)
        width = 0.25
        for i, model in enumerate(models):
            rmse_vals = []
            for subset in order:
                row = summary[(summary["subset"] == subset) & (summary["model"] == model)]
                rmse_vals.append(float(row["rmse"].iloc[0]) if len(row) else np.nan)
            ax.bar(x + (i - 1) * width, rmse_vals, width=width, label=model)
        ax.set_xticks(x)
        ax.set_xticklabels(order)
        ax.set_ylabel("RMSE")
        ax.set_title("NASA C-MAPSS RUL benchmark (lower is better)")
        ax.grid(True, axis="y", alpha=0.25)
        ax.legend()
        fig.tight_layout()
        fig.savefig(outdir / "nasa_benchmark_rmse.png", dpi=160)
        plt.close(fig)


def _standardize_fit(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    std = np.where(std < 1e-12, 1.0, std)
    return mean, std


def _standardize_apply(X: np.ndarray, mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    return (X - mean) / std


# ---------------------- Multi-source fusion hooks ---------------------


def _augment_with_history(df: pd.DataFrame, history_df: Optional[pd.DataFrame], strength: int) -> pd.DataFrame:
    """Append a subsample of historical records as pseudo-samples.

    This is a pragmatic (paper-friendly) way to demonstrate multi-source fusion
    without building a full hierarchical model.

    - strength=0 disables augmentation.
    - If history_df is None, no change.

    Expected columns: at minimum, df columns used in feature selection +
    'time_to_failure' and 'is_censored'.
    """
    strength = int(max(0, strength))
    if strength == 0 or history_df is None or len(history_df) == 0:
        return df

    # Sample with replacement to emulate prior strength.
    rng = np.random.default_rng(0)
    idx = rng.choice(len(history_df), size=strength, replace=True)
    extra = history_df.iloc[idx].copy()

    # Ensure required columns exist
    extra = extra[[c for c in df.columns if c in extra.columns]]
    extra["sample_id"] = np.arange(len(df), len(df) + len(extra))
    return pd.concat([df, extra], axis=0, ignore_index=True)


def _augment_with_expert(df: pd.DataFrame, strength: int, mode_probs: Optional[Iterable[float]] = None) -> pd.DataFrame:
    """Inject pseudo failure-time records from a simple expert prior.

    We keep it minimal: expert opinions define a broad prior over time-to-failure,
    implemented as a lognormal distribution (positive support, heavy tails).

    - strength=0 disables.
    - The pseudo-samples are marked as not censored.

    This is intentionally lightweight: it supports the paper narrative (expert
    knowledge integration) without introducing many new modeling assumptions.
    """
    strength = int(max(0, strength))
    if strength == 0:
        return df

    # Default: vague prior centered around the empirical median.
    t = df.loc[~df["is_censored"].astype(bool), "time_to_failure"].to_numpy(dtype=float)
    t = t[t > 0]
    if t.size == 0:
        median = 40.0
    else:
        median = float(np.median(t))

    # Set lognormal params from median and a conservative sigma.
    sigma = 0.45
    mu = np.log(max(1e-6, median))

    rng = np.random.default_rng(1)
    pseudo_t = rng.lognormal(mean=mu, sigma=sigma, size=strength)

    # Assign a "soft" true_mode if present; otherwise omit.
    if mode_probs is None:
        mode_probs = [0.4, 0.3, 0.2, 0.1]
    mode_probs = np.asarray(list(mode_probs), dtype=float)
    mode_probs = mode_probs / max(1e-12, mode_probs.sum())
    pseudo_mode = rng.choice(len(mode_probs), size=strength, p=mode_probs)

    # Build minimal rows by sampling an existing row and replacing time.
    base = df.sample(n=strength, replace=True, random_state=2).copy()
    base["time_to_failure"] = pseudo_t
    base["is_censored"] = False
    if "true_mode" in base.columns:
        base["true_mode"] = pseudo_mode
    if "mode_name" in base.columns:
        base["mode_name"] = base["mode_name"].astype(str) + " (expert)"

    base["sample_id"] = np.arange(len(df), len(df) + len(base))
    return pd.concat([df, base], axis=0, ignore_index=True)


# ------------------------- Kaplan–Meier -------------------------


def km_survival(times: np.ndarray, events: np.ndarray, time_grid: np.ndarray) -> np.ndarray:
    """Kaplan–Meier estimate of survival S(t) on a fixed time grid.

    times: observed time (failure or censor time)
    events: 1 if failure observed, 0 if right-censored
    """
    times = np.asarray(times, dtype=float).reshape(-1)
    events = np.asarray(events, dtype=int).reshape(-1)
    if times.size == 0:
        return np.ones_like(time_grid, dtype=float)

    # Sort by time
    order = np.argsort(times)
    times = times[order]
    events = events[order]

    unique_times = np.unique(times)
    S = 1.0
    S_at = {}

    n = times.size
    for ut in unique_times:
        at_risk = int(np.sum(times >= ut))
        d = int(np.sum((times == ut) & (events == 1)))
        if at_risk <= 0:
            continue
        if d > 0:
            S *= (1.0 - d / at_risk)
        S_at[ut] = S

    # Step function: S(t) = S at max event time <= t
    out = np.ones_like(time_grid, dtype=float)
    sorted_ut = np.array(sorted(S_at.keys()), dtype=float)
    sorted_S = np.array([S_at[x] for x in sorted_ut], dtype=float)
    for i, tg in enumerate(time_grid):
        j = np.searchsorted(sorted_ut, tg, side="right") - 1
        out[i] = 1.0 if j < 0 else float(sorted_S[j])
    return out


def km_bootstrap_ci(
    times: np.ndarray,
    events: np.ndarray,
    time_grid: np.ndarray,
    n_boot: int,
    ci: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Bootstrap confidence band for KM survival on a fixed grid."""
    times = np.asarray(times, dtype=float).reshape(-1)
    events = np.asarray(events, dtype=int).reshape(-1)

    if times.size < 4 or int(n_boot) <= 0:
        S = km_survival(times, events, time_grid)
        return S, S.copy(), S.copy()

    rng = np.random.default_rng(int(seed))
    n = times.size

    samples = np.zeros((int(n_boot), time_grid.size), dtype=float)
    for b in range(int(n_boot)):
        idx = rng.choice(n, size=n, replace=True)
        samples[b] = km_survival(times[idx], events[idx], time_grid)

    alpha = (1.0 - float(ci)) / 2.0
    lo = np.quantile(samples, alpha, axis=0)
    hi = np.quantile(samples, 1.0 - alpha, axis=0)
    mid = np.mean(samples, axis=0)
    return mid, lo, hi


# ------------------------- DPMM (DP mixture) -------------------------


def fit_dpmm_sklearn(X: np.ndarray, K: int, seed: int = 0):
    """Truncated DP mixture via variational Bayes (scikit-learn).

    This is a practical BNP implementation for ESREL-style papers:
    - Dirichlet process prior over mixture weights
    - Variational inference with truncation level K
    """

    X = np.asarray(X, dtype=float)

    model = BayesianGaussianMixture(
        n_components=int(K),
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        max_iter=800,
        random_state=int(seed),
        init_params="kmeans",
        reg_covar=1e-6,
    )
    model.fit(X)

    resp = model.predict_proba(X)
    labels = np.argmax(resp, axis=1)

    # Lightweight "info" dict for logging/CSV
    info = {
        "lower_bound": float(getattr(model, "lower_bound_", np.nan)),
        "converged": bool(getattr(model, "converged_", False)),
        "n_iter": int(getattr(model, "n_iter_", -1)),
    }
    return model, info, labels, resp


# ------------------------- GP degradation (scikit-learn) -------------------------


def _fit_with_convergence_warning_count(
    gpr: GaussianProcessRegressor,
    X: np.ndarray,
    y: np.ndarray,
) -> Tuple[GaussianProcessRegressor, int]:
    """Fit GP and return the number of sklearn ConvergenceWarning observed."""

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always", ConvergenceWarning)
        gpr.fit(X, y)

    n_warn = 0
    for wi in w:
        try:
            if issubclass(wi.category, ConvergenceWarning):
                n_warn += 1
        except Exception:
            continue
    return gpr, int(n_warn)


def _kernel_bound_hits(gpr: GaussianProcessRegressor, *, eps: float) -> Dict[str, int]:
    """Return a lightweight diagnostic of whether fitted kernel params hit bounds.

    sklearn GP ConvergenceWarning is commonly triggered when the optimum lies at
    a bound (e.g., very small noise level or very short length-scale).
    This helper checks closeness of fitted theta to kernel bounds.

    Returns
    -------
    Dict[str, int]
        Keys: n_params, n_hit, any_hit (0/1)
    """

    try:
        ker = getattr(gpr, "kernel_", None)
        if ker is None:
            return {"n_params": 0, "n_hit": 0, "any_hit": 0}
        theta = np.asarray(getattr(ker, "theta"), dtype=float).reshape(-1)
        bounds = np.asarray(getattr(ker, "bounds"), dtype=float)
        if theta.size == 0 or bounds.size == 0:
            return {"n_params": int(theta.size), "n_hit": 0, "any_hit": 0}
        bounds = bounds.reshape(theta.size, 2)
        lo = bounds[:, 0]
        hi = bounds[:, 1]
        # theta is in log-space; bounds are also log-space.
        hit = (np.abs(theta - lo) <= float(eps)) | (np.abs(theta - hi) <= float(eps))
        n_hit = int(np.sum(hit))
        return {"n_params": int(theta.size), "n_hit": int(n_hit), "any_hit": int(n_hit > 0)}
    except Exception:
        return {"n_params": 0, "n_hit": 0, "any_hit": 0}


def _gpr_fit(X: np.ndarray, y: np.ndarray, seed: int, cfg: Optional[Config] = None) -> GaussianProcessRegressor:
    """Fit a robust GP regression model with standardized inputs.

    Uses a small candidate kernel family and selects the best kernel either via
    log-marginal likelihood (LML) or via a simple time holdout RMSE on the last
    few observed points. The holdout option is usually more aligned with the
    extrapolation objective in RUL settings.
    """

    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float).reshape(-1)

    select_method = str(getattr(cfg, "gp_model_selection", "lml") if cfg is not None else "lml").lower()
    if select_method not in ("lml", "holdout"):
        select_method = "lml"

    # Universal-kriging style: linear trend + flexible residual GP + noise.
    # This is important for extrapolation in degradation/RUL settings where
    # stationary kernels alone often extrapolate overly flat.
    n_restarts = int(getattr(cfg, "gp_n_restarts", 2) if cfg is not None else 2)
    family = str(getattr(cfg, "gp_kernel_family", "matern+rbf") if cfg is not None else "matern+rbf").lower()

    holdout_frac = float(getattr(cfg, "gp_holdout_frac", 0.25) if cfg is not None else 0.25)
    holdout_min = int(getattr(cfg, "gp_holdout_min_points", 3) if cfg is not None else 3)
    holdout_max = int(getattr(cfg, "gp_holdout_max_points", 10) if cfg is not None else 10)
    holdout_min_total = int(getattr(cfg, "gp_holdout_min_total", 8) if cfg is not None else 8)

    length_scale = np.ones(X.shape[1], dtype=float)
    # Linear trend + stationary residual kernel + iid noise.
    # Note: Use additive structure (not multiplicative), otherwise uncertainty can blow up.
    trend = DotProduct(sigma_0=1.0)
    # Tighten bounds to reduce common ConvergenceWarning cases (optimum at bounds).
    trend = DotProduct(sigma_0=1.0, sigma_0_bounds=(1e-3, 1e3))
    scale = ConstantKernel(1.0, (1e-3, 1e3))
    noise = WhiteKernel(noise_level=1.0, noise_level_bounds=(1e-6, 1e2))

    kernels = []
    if "matern" in family or family == "matern":
        kernels.append(
            trend
            + scale
            * Matern(
                length_scale=length_scale,
                length_scale_bounds=(1e-2, 1e2),
                nu=2.5,
            )
            + noise
        )
    if "rbf" in family or family == "rbf":
        # RBF can be competitive on very smooth trajectories
        kernels.append(trend + scale * RBF(length_scale=length_scale, length_scale_bounds=(1e-2, 1e2)) + noise)
    if "periodic" in family:
        # Keep periodic component optional; it can overfit if the trace is short.
        from sklearn.gaussian_process.kernels import ExpSineSquared

        kernels.append(trend + scale * ExpSineSquared(length_scale=1.0, periodicity=10.0) + noise)

    if not kernels:
        kernels = [trend + scale * Matern(length_scale=length_scale, nu=2.5) + noise]

    # Select the kernel.
    # - LML selection: fit on all points and compare log-marginal-likelihood.
    # - Holdout selection: fit on early points, score RMSE on last points.
    best_kernel = None
    total_warn = 0
    n_warn_final = 0

    if select_method == "holdout" and X.shape[0] >= max(2, holdout_min_total):
        n = int(X.shape[0])
        n_val = int(round(float(holdout_frac) * n))
        n_val = max(holdout_min, n_val)
        n_val = min(holdout_max, n_val)
        n_val = min(n - 1, n_val)

        n_train = n - n_val
        X_train = X[:n_train]
        y_train = y[:n_train]
        X_val = X[n_train:]
        y_val = y[n_train:]

        mean_tr, std_tr = _standardize_fit(X_train)
        Xz_train = _standardize_apply(X_train, mean_tr, std_tr)
        Xz_val = _standardize_apply(X_val, mean_tr, std_tr)

        best_rmse = np.inf
        for ker in kernels:
            gpr_try = GaussianProcessRegressor(
                kernel=ker,
                alpha=1e-8,
                normalize_y=True,
                random_state=int(seed),
                n_restarts_optimizer=n_restarts,
            )
            gpr_try, n_warn = _fit_with_convergence_warning_count(gpr_try, Xz_train, y_train)
            total_warn += int(n_warn)
            pred = gpr_try.predict(Xz_val)
            rmse = float(np.sqrt(np.mean((pred - y_val) ** 2)))
            if rmse < best_rmse:
                best_rmse = rmse
                best_kernel = ker

    if best_kernel is None:
        # Fallback to LML selection (also used when trajectories are too short).
        mean_all, std_all = _standardize_fit(X)
        Xz_all = _standardize_apply(X, mean_all, std_all)

        best_lml = -np.inf
        for ker in kernels:
            gpr_try = GaussianProcessRegressor(
                kernel=ker,
                alpha=1e-8,
                normalize_y=True,
                random_state=int(seed),
                n_restarts_optimizer=n_restarts,
            )
            gpr_try, n_warn = _fit_with_convergence_warning_count(gpr_try, Xz_all, y)
            total_warn += int(n_warn)
            try:
                lml = float(gpr_try.log_marginal_likelihood())
            except Exception:
                lml = -np.inf
            if lml > best_lml:
                best_lml = lml
                best_kernel = ker

    # Fit final model on all points using the selected kernel.
    mean, std = _standardize_fit(X)
    Xz = _standardize_apply(X, mean, std)
    gpr = GaussianProcessRegressor(
        kernel=best_kernel,
        alpha=1e-8,
        normalize_y=True,
        random_state=int(seed),
        n_restarts_optimizer=n_restarts,
    )
    gpr, n_warn_final = _fit_with_convergence_warning_count(gpr, Xz, y)
    total_warn += int(n_warn_final)

    # Attach scaling for reuse in prediction
    gpr._x_mean = mean  # type: ignore[attr-defined]
    gpr._x_std = std  # type: ignore[attr-defined]
    gpr._convergence_warning_count = int(total_warn)  # type: ignore[attr-defined]
    gpr._convergence_warning_final = bool(int(n_warn_final) > 0)  # type: ignore[attr-defined]
    eps = float(getattr(cfg, "gp_bound_hit_eps", 1e-3) if cfg is not None else 1e-3)
    gpr._kernel_bound_hits = _kernel_bound_hits(gpr, eps=eps)  # type: ignore[attr-defined]
    return gpr


def _gpr_predict(gpr: GaussianProcessRegressor, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    X = np.asarray(X, dtype=float)
    mean = getattr(gpr, "_x_mean")
    std = getattr(gpr, "_x_std")
    Xz = _standardize_apply(X, mean, std)
    mu, std_pred = gpr.predict(Xz, return_std=True)
    var = np.maximum(std_pred**2, 1e-10)
    return np.asarray(mu, dtype=float), np.asarray(var, dtype=float)


def _gpr_predict_cov(gpr: GaussianProcessRegressor, X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """Predict mean and full predictive covariance (for correlated path sampling)."""

    X = np.asarray(X, dtype=float)
    mean = getattr(gpr, "_x_mean")
    std = getattr(gpr, "_x_std")
    Xz = _standardize_apply(X, mean, std)
    mu, cov = gpr.predict(Xz, return_cov=True)
    mu = np.asarray(mu, dtype=float)
    cov = np.asarray(cov, dtype=float)
    # Numerical symmetry + jitter
    cov = 0.5 * (cov + cov.T)
    cov = cov + 1e-8 * np.eye(cov.shape[0], dtype=float)
    return mu, cov


def fit_gp_and_rul(degradation_df: pd.DataFrame, equipment_id: int, cfg: Config) -> Dict[str, float]:
    """Fit GP on one unit's degradation and estimate RUL with uncertainty via MC."""

    equip = degradation_df[degradation_df["equipment_id"] == int(equipment_id)].copy()
    if len(equip) == 0:
        raise ValueError(f"No degradation data for equipment_id={equipment_id}")
    equip = equip.sort_values("cycle")
    return fit_gp_and_rul_from_df(equip, equipment_id=equipment_id, cfg=cfg)


def fit_gp_and_rul_from_df(equip: pd.DataFrame, equipment_id: int, cfg: Config) -> Dict[str, float]:
    """Fit GP on a provided time-series (one unit) and estimate RUL.

    Expected columns: cycle, performance, optional temperature/reuse_count.
    """
    equip = equip.sort_values("cycle")
    current_cycle = int(equip["cycle"].iloc[-1])

    cols = ["cycle"]
    for c in ("temperature", "reuse_count"):
        if c in equip.columns:
            cols.append(c)

    X = equip[cols].to_numpy(dtype=float)
    y = equip["performance"].to_numpy(dtype=float)

    gpr = _gpr_fit(X, y, seed=cfg.seed + int(equipment_id), cfg=cfg)
    warn_total = int(getattr(gpr, "_convergence_warning_count", 0))
    warn_final = bool(getattr(gpr, "_convergence_warning_final", False))

    horizon = int(cfg.gp_max_future)
    future_cycles = np.arange(current_cycle, current_cycle + horizon, dtype=float)
    x_current = X[-1].copy()
    Xf = np.tile(x_current, (horizon, 1))
    Xf[:, 0] = future_cycles

    # Sample correlated future trajectories from GP predictive covariance.
    # This avoids under/over-estimating threshold-crossing uncertainty caused by
    # treating future points as independent.
    mu, cov = _gpr_predict_cov(gpr, Xf)

    rng = np.random.default_rng(cfg.seed + 123 + int(equipment_id))
    mc = int(cfg.gp_mc_paths)
    if mc <= 0:
        mc = 1

    y_paths = rng.multivariate_normal(mean=mu, cov=cov, size=mc)
    y_paths = np.asarray(y_paths, dtype=float)

    hits = y_paths <= float(cfg.gp_threshold)
    has_hit = hits.any(axis=1)
    first_hit = np.argmax(hits, axis=1)  # returns 0 if no hit; use has_hit mask
    rul_samples = np.where(has_hit, first_hit.astype(float), float(horizon))

    alpha = (1.0 - float(cfg.gp_ci)) / 2.0
    return {
        "equipment_id": int(equipment_id),
        "current_cycle": int(current_cycle),
        "rul_mean": float(np.mean(rul_samples)),
        "rul_median": float(np.quantile(rul_samples, 0.5)),
        "rul_lower": float(np.quantile(rul_samples, alpha)),
        "rul_upper": float(np.quantile(rul_samples, 1.0 - alpha)),
        "threshold": float(cfg.gp_threshold),
        "gp_convergence_warning_total": float(warn_total),
        "gp_convergence_warning_final": float(1.0 if warn_final else 0.0),
    }


def _conformal_q_from_abs_errors(abs_err: np.ndarray, ci: float) -> float:
    """Return conformal radius q for two-sided symmetric interval with target CI.

    Uses the standard finite-sample correction: q is the k-th order statistic where
    k = ceil((n+1) * (1 - alpha)), alpha = 1 - ci.
    """

    abs_err = np.asarray(abs_err, dtype=float)
    abs_err = abs_err[np.isfinite(abs_err)]
    n = int(abs_err.size)
    if n <= 0:
        return float("nan")
    alpha = float(1.0 - ci)
    k = int(np.ceil((n + 1) * (1.0 - alpha)))
    k = max(1, min(k, n))
    return float(np.sort(abs_err)[k - 1])


def _first_failure_cycle(degradation_df: pd.DataFrame, equipment_id: int) -> Optional[int]:
    sub = degradation_df[degradation_df["equipment_id"] == int(equipment_id)].sort_values("cycle")
    if "failed" not in sub.columns:
        return None
    fail_rows = sub[sub["failed"].astype(bool)]
    if len(fail_rows) == 0:
        return None
    return int(fail_rows["cycle"].min())


def evaluate_gp_rul_coverage(degradation_df: pd.DataFrame, cfg: Config, outdir: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate GP RUL interval calibration on simulated degradation data.

    For each unit, fit GP on a prefix ending at obs_cycle < true failure cycle,
    then evaluate point error and CI coverage.
    """
    rows = []
    for equipment_id in sorted(degradation_df["equipment_id"].unique()):
        fail_cycle = _first_failure_cycle(degradation_df, equipment_id)
        if fail_cycle is None or fail_cycle <= 3:
            continue

        obs_ratio = float(cfg.gp_obs_ratio)
        obs_cycle = max(2, int(np.floor(obs_ratio * float(fail_cycle))))
        true_rul = float(fail_cycle - obs_cycle)

        equip = degradation_df[degradation_df["equipment_id"] == int(equipment_id)].copy()
        equip = equip.sort_values("cycle")
        equip_obs = equip[equip["cycle"] <= obs_cycle].copy()
        if len(equip_obs) < 5:
            continue

        pred = fit_gp_and_rul_from_df(equip_obs, equipment_id=int(equipment_id), cfg=cfg)
        lo = float(pred["rul_lower"])
        hi = float(pred["rul_upper"])
        mean = float(pred["rul_mean"])
        med = float(pred.get("rul_median", mean))

        rows.append(
            {
                "equipment_id": int(equipment_id),
                "true_mode": int(equip_obs["true_mode"].iloc[-1]) if "true_mode" in equip_obs.columns else np.nan,
                "fail_cycle": int(fail_cycle),
                "obs_cycle": int(obs_cycle),
                "true_rul": float(true_rul),
                "pred_rul_mean": mean,
                "pred_rul_median": med,
                "pred_rul_lower": lo,
                "pred_rul_upper": hi,
                "abs_error_mean": float(abs(mean - true_rul)),
                "sq_error_mean": float((mean - true_rul) ** 2),
                "abs_error_median": float(abs(med - true_rul)),
                "sq_error_median": float((med - true_rul) ** 2),
                "covered": bool((lo <= true_rul) and (true_rul <= hi)),
                "interval_width": float(hi - lo),
                "gp_convergence_warning_total": float(pred.get("gp_convergence_warning_total", np.nan)),
                "gp_convergence_warning_final": float(pred.get("gp_convergence_warning_final", np.nan)),
            }
        )

    per_unit = pd.DataFrame(rows).sort_values("equipment_id")
    if len(per_unit) == 0:
        summary = pd.DataFrame(
            [
                {
                    "n_units": 0,
                    "mae": np.nan,
                    "rmse": np.nan,
                    "coverage": np.nan,
                    "avg_width": np.nan,
                    "ci": float(cfg.gp_ci),
                    "threshold": float(cfg.gp_threshold),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            ]
        )
        return per_unit, summary

    # Raw interval metrics
    mae_mean = float(per_unit["abs_error_mean"].mean())
    rmse_mean = float(np.sqrt(per_unit["sq_error_mean"].mean()))
    mae_median = float(per_unit["abs_error_median"].mean())
    rmse_median = float(np.sqrt(per_unit["sq_error_median"].mean()))
    coverage_raw = float(per_unit["covered"].mean())
    avg_width_raw = float(per_unit["interval_width"].mean())

    # Leave-one-out conformal calibration across units (exchangeable errors).
    # We provide two options:
    #   (1) Symmetric radius around point prediction (can be overly wide)
    #   (2) Interval-score calibration (CQR-style): expand raw [lo, hi] minimally
    abs_err_all = per_unit["abs_error_median"].to_numpy(dtype=float)
    pred_point_all = per_unit["pred_rul_median"].to_numpy(dtype=float)
    true_all = per_unit["true_rul"].to_numpy(dtype=float)
    n = int(len(per_unit))
    q_loo = np.full(n, np.nan, dtype=float)
    for i in range(n):
        others = np.delete(abs_err_all, i)
        q_loo[i] = _conformal_q_from_abs_errors(others, ci=float(cfg.gp_ci))

    lo_c = pred_point_all - q_loo
    hi_c = pred_point_all + q_loo
    covered_c = (lo_c <= true_all) & (true_all <= hi_c)
    width_c = hi_c - lo_c

    per_unit["pred_rul_lower_conformal"] = lo_c
    per_unit["pred_rul_upper_conformal"] = hi_c
    per_unit["covered_conformal"] = covered_c
    per_unit["interval_width_conformal"] = width_c

    coverage_conformal = float(np.nanmean(covered_c.astype(float)))
    avg_width_conformal = float(np.nanmean(width_c))

    # CQR-style conformalization of the *interval* itself.
    raw_lo = per_unit["pred_rul_lower"].to_numpy(dtype=float)
    raw_hi = per_unit["pred_rul_upper"].to_numpy(dtype=float)
    score_all = np.maximum.reduce([raw_lo - true_all, true_all - raw_hi, np.zeros_like(true_all)])

    q_int_loo = np.full(n, np.nan, dtype=float)
    for i in range(n):
        others = np.delete(score_all, i)
        q_int_loo[i] = _conformal_q_from_abs_errors(others, ci=float(cfg.gp_ci))

    lo_int = raw_lo - q_int_loo
    hi_int = raw_hi + q_int_loo
    covered_int = (lo_int <= true_all) & (true_all <= hi_int)
    width_int = hi_int - lo_int

    per_unit["pred_rul_lower_conformal_int"] = lo_int
    per_unit["pred_rul_upper_conformal_int"] = hi_int
    per_unit["covered_conformal_int"] = covered_int
    per_unit["interval_width_conformal_int"] = width_int

    coverage_conformal_int = float(np.nanmean(covered_int.astype(float)))
    avg_width_conformal_int = float(np.nanmean(width_int))

    summary = pd.DataFrame(
        [
            {
                "n_units": int(len(per_unit)),
                "mae": mae_median,
                "rmse": rmse_median,
                "coverage": coverage_raw,
                "avg_width": avg_width_raw,
                "mae_mean": mae_mean,
                "rmse_mean": rmse_mean,
                "mae_median": mae_median,
                "rmse_median": rmse_median,
                "coverage_raw": coverage_raw,
                "coverage_conformal": coverage_conformal,
                "coverage_conformal_int": coverage_conformal_int,
                "avg_width_raw": avg_width_raw,
                "avg_width_conformal": avg_width_conformal,
                "avg_width_conformal_int": avg_width_conformal_int,
                "gp_warning_rate_final": float(np.nanmean(per_unit["gp_convergence_warning_final"].to_numpy(dtype=float)))
                if "gp_convergence_warning_final" in per_unit.columns
                else np.nan,
                "ci": float(cfg.gp_ci),
                "threshold": float(cfg.gp_threshold),
                "obs_ratio": float(cfg.gp_obs_ratio),
            }
        ]
    )

    # Conditional summary: warning vs no-warning (based on final GP fit)
    try:
        if "gp_convergence_warning_final" in per_unit.columns:
            warn_mask = per_unit["gp_convergence_warning_final"].to_numpy(dtype=float) >= 0.5
            for tag, mask in (("warn", warn_mask), ("no_warn", ~warn_mask)):
                if int(np.sum(mask)) <= 0:
                    continue
                summary.loc[0, f"n_units_{tag}"] = int(np.sum(mask))
                summary.loc[0, f"coverage_raw_{tag}"] = float(np.mean(per_unit.loc[mask, "covered"].to_numpy(dtype=float)))
                summary.loc[0, f"avg_width_raw_{tag}"] = float(np.mean(per_unit.loc[mask, "interval_width"].to_numpy(dtype=float)))
                summary.loc[0, f"coverage_conformal_int_{tag}"] = float(
                    np.mean(per_unit.loc[mask, "covered_conformal_int"].to_numpy(dtype=float))
                )
                summary.loc[0, f"avg_width_conformal_int_{tag}"] = float(
                    np.mean(per_unit.loc[mask, "interval_width_conformal_int"].to_numpy(dtype=float))
                )
    except Exception:
        pass

    per_unit.to_csv(outdir / "gp_rul_coverage_by_unit.csv", index=False)
    summary.to_csv(outdir / "gp_rul_coverage_summary.csv", index=False)
    return per_unit, summary


def run_gp_rul_robustness(
    base_cfg: Config,
    repeats: int,
    obs_ratios: Tuple[float, ...],
    outdir: Path,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Run GP-RUL evaluation for multiple seeds and observation ratios.

    Writes:
      - rul_robustness_runs.csv (one row per run)
      - rul_robustness_summary.csv (mean±std grouped by obs_ratio)
      - rul_robustness.png (coverage/width and RMSE vs obs_ratio)
    """

    rows = []
    from cryogenic_reliability_data_generator import CryogenicEquipmentDataGenerator

    for r in range(int(repeats)):
        seed_r = int(base_cfg.seed) + 100 * r
        for obs_ratio in obs_ratios:
            cfg = replace(base_cfg, seed=seed_r, gp_obs_ratio=float(obs_ratio))
            gen = CryogenicEquipmentDataGenerator(random_seed=cfg.seed)
            degradation_df = gen.generate_degradation_data(
                n_equipment=cfg.n_degradation_units,
                max_cycles=cfg.max_cycles,
                include_crack_failure=False,
            )

            per_unit, summary = evaluate_gp_rul_coverage(degradation_df, cfg=cfg, outdir=outdir)
            s = summary.iloc[0].to_dict()
            s.update(
                {
                    "seed": int(cfg.seed),
                    "repeat": int(r),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            )
            rows.append(s)

    runs = pd.DataFrame(rows)
    runs.to_csv(outdir / "rul_robustness_runs.csv", index=False)

    def _mean_std(col: str) -> Tuple[float, float]:
        v = runs[col].to_numpy(dtype=float)
        return float(np.nanmean(v)), float(np.nanstd(v, ddof=1)) if np.sum(np.isfinite(v)) > 1 else (float(np.nanmean(v)), 0.0)

    summary_rows = []
    for obs_ratio in sorted(set(float(x) for x in obs_ratios)):
        sub = runs[np.isclose(runs["obs_ratio"].to_numpy(dtype=float), float(obs_ratio))]
        if len(sub) == 0:
            continue
        row = {
            "obs_ratio": float(obs_ratio),
            "n_runs": int(len(sub)),
            "n_units_mean": float(sub["n_units"].mean()),
        }
        for key in (
            "mae",
            "rmse",
            "coverage_raw",
            "coverage_conformal_int",
            "avg_width_raw",
            "avg_width_conformal_int",
        ):
            m = float(sub[key].mean())
            sd = float(sub[key].std(ddof=1)) if len(sub) > 1 else 0.0
            row[f"{key}_mean"] = m
            row[f"{key}_std"] = sd
        summary_rows.append(row)

    agg = pd.DataFrame(summary_rows).sort_values("obs_ratio")
    agg.to_csv(outdir / "rul_robustness_summary.csv", index=False)

    # Plot (optional)
    plt = _try_import_matplotlib()
    if plt is not None and len(agg) > 0:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11.0, 4.2))
        x = agg["obs_ratio"].to_numpy(dtype=float)

        # Black-and-white friendly styles
        st_raw = dict(color="black", linestyle="-", marker="o")
        st_conf = dict(color="black", linestyle="--", marker="s")

        # Coverage vs obs_ratio
        ax1.errorbar(
            x,
            agg["coverage_raw_mean"].to_numpy(dtype=float),
            yerr=agg["coverage_raw_std"].to_numpy(dtype=float),
            fmt="o",
            linewidth=1.8,
            ecolor="0.5",
            elinewidth=1.0,
            capsize=3,
            label="Raw",
            **st_raw,
        )
        ax1.errorbar(
            x,
            agg["coverage_conformal_int_mean"].to_numpy(dtype=float),
            yerr=agg["coverage_conformal_int_std"].to_numpy(dtype=float),
            fmt="o",
            linewidth=1.8,
            ecolor="0.5",
            elinewidth=1.0,
            capsize=3,
            label="Conformal calibrated",
            **st_conf,
        )
        ax1.axhline(float(base_cfg.gp_ci), color="k", linestyle="--", linewidth=1.2, label="Target")
        ax1.set_ylim(0.0, 1.05)
        ax1.set_xlabel("Observation ratio")
        ax1.set_ylabel("Empirical coverage")
        ax1.set_title("Coverage vs observation ratio")
        ax1.grid(True, alpha=0.25)
        ax1.legend(loc="best")

        # RMSE vs obs_ratio
        ax2.errorbar(
            x,
            agg["rmse_mean"].to_numpy(dtype=float),
            yerr=agg["rmse_std"].to_numpy(dtype=float),
            fmt="o",
            linewidth=1.8,
            color="black",
            linestyle="-",
            marker="o",
            ecolor="0.5",
            elinewidth=1.0,
            capsize=3,
            label="RMSE",
        )
        ax2.set_xlabel("Observation ratio")
        ax2.set_ylabel("RMSE (cycles)")
        ax2.set_title("RUL accuracy vs observation ratio")
        ax2.grid(True, alpha=0.25)
        ax2.legend(loc="best")

        fig.tight_layout()
        fig.savefig(outdir / "rul_robustness.png", dpi=160)

        # Also write a paper-ready B/W figure copy under the output directory.
        try:
            bw_dir = outdir / "figures_bw"
            bw_dir.mkdir(parents=True, exist_ok=True)
            fig.savefig(bw_dir / "fig6_robustness.png", dpi=300)
        except Exception:
            pass
        plt.close(fig)

    return runs, agg


# ----------------------------- Main flow -----------------------------


def _select_features_for_dpmm(df: pd.DataFrame) -> Tuple[np.ndarray, Tuple[str, ...]]:
    """Feature set aligned with cryogenic narrative + generator columns."""
    cols = []
    for c in (
        "temperature",
        "stress_level",
        "reuse_count",
        "vibration",
        "pressure_drop",
        "energy_consumed",
        "arrhenius_factor",
        "brittleness_factor",
        "crack_length",
    ):
        if c in df.columns:
            cols.append(c)

    if not cols:
        raise ValueError("No usable feature columns found for DPMM")

    X = df[cols].to_numpy(dtype=float)
    mean, std = _standardize_fit(X)
    Xz = _standardize_apply(X, mean, std)
    return Xz, tuple(cols)


def compute_clustering_baselines(
    Xz: np.ndarray,
    y_true: np.ndarray,
    seed: int,
    K_trunc: int,
    gmm_k_min: int = 2,
    gmm_k_max: int = 12,
) -> pd.DataFrame:
    """Compute simple clustering baselines for interpretability.

    Baselines
    - DP-GMM (variational, truncated at K_trunc) (already used in the main pipeline)
    - KMeans with K=argmax occupied components from DP-GMM (fair-ish comparison)
    - GMM with K selected by BIC over [gmm_k_min, gmm_k_max]

    Returns
    -------
    pd.DataFrame with columns: method, K, ari, nmi
    """

    Xz = np.asarray(Xz, dtype=float)
    y_true = np.asarray(y_true, dtype=int).reshape(-1)

    rows = []

    # DP-GMM (same as in pipeline)
    dp_model, _info, labels_dp, resp = fit_dpmm_sklearn(Xz, K=int(K_trunc), seed=int(seed))
    K_eff = int(np.unique(labels_dp).size)
    rows.append(
        {
            "method": "DP-GMM (VB, trunc)",
            "K": int(K_eff),
            "ari": float(adjusted_rand_score(y_true, labels_dp)),
            "nmi": float(normalized_mutual_info_score(y_true, labels_dp)),
        }
    )

    # KMeans with K matched to effective number of occupied clusters
    km = KMeans(n_clusters=max(2, int(K_eff)), n_init=20, random_state=int(seed))
    labels_km = km.fit_predict(Xz)
    rows.append(
        {
            "method": "KMeans (K matched)",
            "K": int(np.unique(labels_km).size),
            "ari": float(adjusted_rand_score(y_true, labels_km)),
            "nmi": float(normalized_mutual_info_score(y_true, labels_km)),
        }
    )

    # GMM with BIC-selected K
    best = None
    for k in range(int(gmm_k_min), int(gmm_k_max) + 1):
        gmm = GaussianMixture(
            n_components=int(k),
            covariance_type="full",
            reg_covar=1e-6,
            max_iter=400,
            random_state=int(seed),
            init_params="kmeans",
        )
        gmm.fit(Xz)
        bic = float(gmm.bic(Xz))
        if best is None or bic < best[0]:
            best = (bic, gmm)

    assert best is not None
    gmm_best = best[1]
    labels_gmm = gmm_best.predict(Xz)
    rows.append(
        {
            "method": "GMM (BIC K)",
            "K": int(np.unique(labels_gmm).size),
            "ari": float(adjusted_rand_score(y_true, labels_gmm)),
            "nmi": float(normalized_mutual_info_score(y_true, labels_gmm)),
        }
    )

    # For completeness, log how concentrated the DP weights are (diagnostic)
    try:
        w = getattr(dp_model, "weights_", None)
        if w is not None:
            rows.append(
                {
                    "method": "DP-GMM weight mass top-3",
                    "K": 3,
                    "ari": float(np.sum(np.sort(w)[-3:])),
                    "nmi": float(np.nan),
                }
            )
    except Exception:
        pass

    return pd.DataFrame(rows)


def infer_unit_modes_from_degradation(
    degradation_df: pd.DataFrame,
    K: int,
    seed: int,
    *,
    prefix_cycle_by_unit: Optional[Dict[int, int]] = None,
    max_points: int = 20,
) -> pd.DataFrame:
    """Infer per-unit latent modes from degradation covariates (unsupervised).

    We build a compact per-unit feature vector (temperature/reuse + early slope)
    and fit a DP-GMM. This produces a mode label and confidence per unit.
    """

    unit_ids = [int(u) for u in sorted(degradation_df["equipment_id"].unique())]
    unit_feat = _build_unit_mode_features(
        degradation_df,
        unit_ids=unit_ids,
        prefix_cycle_by_unit=prefix_cycle_by_unit,
        max_points=max_points,
    )
    X = unit_feat[["f_temp", "f_reuse", "f_slope"]].to_numpy(dtype=float)
    mean, std = _standardize_fit(X)
    Xz = _standardize_apply(X, mean, std)

    model = BayesianGaussianMixture(
        n_components=int(K),
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        max_iter=800,
        random_state=int(seed),
        init_params="kmeans",
        reg_covar=1e-6,
    )
    model.fit(Xz)
    resp = model.predict_proba(Xz)
    labels = np.argmax(resp, axis=1)
    conf = resp[np.arange(resp.shape[0]), labels]
    unit_feat["mode_hat"] = labels.astype(int)
    unit_feat["mode_prob"] = conf.astype(float)
    return unit_feat


def _infer_unit_modes_dpmm_fit_predict(
    degradation_df: pd.DataFrame,
    *,
    train_unit_ids: list[int],
    all_unit_ids: list[int],
    K: int,
    seed: int,
    prefix_cycle_by_unit: Optional[Dict[int, int]] = None,
    max_points: int = 20,
    return_resp: bool = False,
) -> pd.DataFrame:
    """Fit DP-GMM on training units, then predict mode labels for all units.

    This avoids transductive leakage from test units into the unsupervised mode model.
    """

    train_feat = _build_unit_mode_features(
        degradation_df,
        unit_ids=train_unit_ids,
        prefix_cycle_by_unit=prefix_cycle_by_unit,
        max_points=max_points,
    )
    all_feat = _build_unit_mode_features(
        degradation_df,
        unit_ids=all_unit_ids,
        prefix_cycle_by_unit=prefix_cycle_by_unit,
        max_points=max_points,
    )
    if len(train_feat) == 0 or len(all_feat) == 0:
        return pd.DataFrame(columns=["equipment_id", "mode_hat", "mode_prob"])

    Xtr = train_feat[["f_temp", "f_reuse", "f_slope"]].to_numpy(dtype=float)
    mean, std = _standardize_fit(Xtr)
    Xtrz = _standardize_apply(Xtr, mean, std)

    model = BayesianGaussianMixture(
        n_components=int(K),
        weight_concentration_prior_type="dirichlet_process",
        covariance_type="full",
        max_iter=800,
        random_state=int(seed),
        init_params="kmeans",
        reg_covar=1e-6,
    )
    model.fit(Xtrz)

    Xa = all_feat[["f_temp", "f_reuse", "f_slope"]].to_numpy(dtype=float)
    Xaz = _standardize_apply(Xa, mean, std)
    resp = model.predict_proba(Xaz)
    labels = np.argmax(resp, axis=1)
    conf = resp[np.arange(resp.shape[0]), labels]
    out = all_feat[["equipment_id", "f_temp", "f_reuse", "f_slope"]].copy()
    out["mode_hat"] = labels.astype(int)
    out["mode_prob"] = conf.astype(float)
    if bool(return_resp):
        for k in range(int(resp.shape[1])):
            out[f"resp_{k}"] = resp[:, k].astype(float)
    return out.sort_values("equipment_id")


def _make_future_design_matrix(
    equip_obs: pd.DataFrame,
    cfg: Config,
    *,
    extra_const_features: Optional[Tuple[float, ...]] = None,
) -> np.ndarray:
    """Build the future design matrix for pooled GP prediction.

    Base columns are [cycle, temperature, reuse_count] when available.
    Optional extra_const_features are appended as constant columns across the horizon.
    """

    equip_obs = equip_obs.sort_values("cycle")
    current_cycle = int(equip_obs["cycle"].iloc[-1])

    cols = ["cycle"]
    for c in ("temperature", "reuse_count"):
        if c in equip_obs.columns:
            cols.append(c)

    X_current = equip_obs[cols].to_numpy(dtype=float)
    x_last = X_current[-1].copy()

    horizon = int(cfg.gp_max_future)
    future_cycles = np.arange(current_cycle, current_cycle + horizon, dtype=float)
    Xf = np.tile(x_last, (horizon, 1))
    Xf[:, 0] = future_cycles

    if extra_const_features is not None and len(extra_const_features) > 0:
        extra = np.tile(np.asarray(extra_const_features, dtype=float).reshape(1, -1), (horizon, 1))
        Xf = np.concatenate([Xf, extra], axis=1)
    return np.asarray(Xf, dtype=float)


def _predict_rul_from_prefit_gp(
    gpr: GaussianProcessRegressor,
    equip_obs: pd.DataFrame,
    cfg: Config,
    seed: int,
) -> Dict[str, float]:
    """Estimate RUL for one unit given a pre-fit GP on pooled data."""

    equip_obs = equip_obs.sort_values("cycle")
    current_cycle = int(equip_obs["cycle"].iloc[-1])
    Xf = _make_future_design_matrix(equip_obs, cfg)
    horizon = int(cfg.gp_max_future)

    mu, cov = _gpr_predict_cov(gpr, Xf)
    rng = np.random.default_rng(int(seed))

    mc = int(cfg.gp_mc_paths)
    if mc <= 0:
        mc = 1
    y_paths = rng.multivariate_normal(mean=mu, cov=cov, size=mc)
    y_paths = np.asarray(y_paths, dtype=float)

    hits = y_paths <= float(cfg.gp_threshold)
    has_hit = hits.any(axis=1)
    first_hit = np.argmax(hits, axis=1)
    rul_samples = np.where(has_hit, first_hit.astype(float), float(horizon))

    alpha = (1.0 - float(cfg.gp_ci)) / 2.0
    return {
        "current_cycle": int(current_cycle),
        "rul_mean": float(np.mean(rul_samples)),
        "rul_median": float(np.quantile(rul_samples, 0.5)),
        "rul_lower": float(np.quantile(rul_samples, alpha)),
        "rul_upper": float(np.quantile(rul_samples, 1.0 - alpha)),
        "threshold": float(cfg.gp_threshold),
    }


def _predict_rul_from_mixture_of_prefit_gps(
    *,
    experts: Dict[int, GaussianProcessRegressor],
    weights: Dict[int, float],
    equip_obs: pd.DataFrame,
    cfg: Config,
    seed: int,
) -> Dict[str, float]:
    """Estimate RUL by Monte Carlo under a mixture over multiple pooled GP experts.

    We approximate a soft routing mixture by sampling an expert index per MC path,
    then sampling a correlated future trajectory from that expert.
    """

    equip_obs = equip_obs.sort_values("cycle")
    current_cycle = int(equip_obs["cycle"].iloc[-1])
    Xf = _make_future_design_matrix(equip_obs, cfg)

    keys = [int(k) for k in sorted(experts.keys()) if int(k) in weights]
    if len(keys) == 0:
        # Fallback: pick any expert
        any_k = next(iter(experts.keys()))
        return _predict_rul_from_prefit_gp(experts[int(any_k)], equip_obs, cfg, seed)

    w = np.asarray([float(weights[int(k)]) for k in keys], dtype=float)
    w = np.maximum(w, 0.0)
    if float(w.sum()) <= 0:
        w = np.ones_like(w, dtype=float)
    w = w / float(w.sum())

    rng = np.random.default_rng(int(seed))
    mc = int(cfg.gp_mc_paths)
    if mc <= 0:
        mc = 1

    # Allocate paths per expert
    counts = rng.multinomial(int(mc), w)
    horizon = int(cfg.gp_max_future)
    rul_samples_all: list[np.ndarray] = []
    for idx, k in enumerate(keys):
        n_k = int(counts[idx])
        if n_k <= 0:
            continue
        gpr = experts[int(k)]
        mu, cov = _gpr_predict_cov(gpr, Xf)
        y_paths = rng.multivariate_normal(mean=mu, cov=cov, size=n_k)
        y_paths = np.asarray(y_paths, dtype=float)
        hits = y_paths <= float(cfg.gp_threshold)
        has_hit = hits.any(axis=1)
        first_hit = np.argmax(hits, axis=1)
        rul_samples = np.where(has_hit, first_hit.astype(float), float(horizon))
        rul_samples_all.append(np.asarray(rul_samples, dtype=float))

    if len(rul_samples_all) == 0:
        rul_samples = np.asarray([float(horizon)], dtype=float)
    else:
        rul_samples = np.concatenate(rul_samples_all, axis=0)

    alpha = (1.0 - float(cfg.gp_ci)) / 2.0
    return {
        "current_cycle": int(current_cycle),
        "rul_mean": float(np.mean(rul_samples)),
        "rul_median": float(np.quantile(rul_samples, 0.5)),
        "rul_lower": float(np.quantile(rul_samples, alpha)),
        "rul_upper": float(np.quantile(rul_samples, 1.0 - alpha)),
        "threshold": float(cfg.gp_threshold),
    }


def evaluate_gp_rul_coverage_pooled_variant(
    degradation_df: pd.DataFrame,
    cfg: Config,
    outdir: Path,
    *,
    variant: str,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate pooled coupling variants under unit-level CV.

    Variants:
      - global: pooled global GP
      - hard_expert: mode-expert hard routing (argmax)
      - mode_covariate: pooled global GP with inferred mode_hat appended as a covariate
      - soft_expert: mixture-of-experts soft routing using DP-GMM responsibilities
    """

    v = str(variant).strip().lower()
    if v not in ("global", "hard_expert", "mode_covariate", "soft_expert"):
        raise ValueError(f"Unknown pooled coupling variant: {variant}")
    mode_experts = bool(v in ("hard_expert", "soft_expert"))
    use_mode_covariate = bool(v == "mode_covariate")
    use_soft_expert = bool(v == "soft_expert")

    work = degradation_df.copy()
    if "temperature" not in work.columns:
        work["temperature"] = 0.0
    if "reuse_count" not in work.columns:
        work["reuse_count"] = 0.0

    # Precompute fail/obs cycles per unit
    obs_ratio = float(cfg.gp_obs_ratio)
    fail_by_unit: Dict[int, int] = {}
    obs_by_unit: Dict[int, int] = {}
    for equipment_id in sorted(work["equipment_id"].unique()):
        fail_cycle = _first_failure_cycle(work, int(equipment_id))
        if fail_cycle is None:
            continue
        fail_by_unit[int(equipment_id)] = int(fail_cycle)
        obs_by_unit[int(equipment_id)] = max(2, int(np.floor(obs_ratio * float(fail_cycle))))

    unit_ids = [int(u) for u in sorted(work["equipment_id"].unique())]
    unit_ids = [u for u in unit_ids if int(u) in fail_by_unit]
    if len(unit_ids) == 0:
        per_unit = pd.DataFrame()
        summary = pd.DataFrame(
            [
                {
                    "model": v,
                    "n_units": 0,
                    "mae": np.nan,
                    "rmse": np.nan,
                    "coverage_raw": np.nan,
                    "avg_width_raw": np.nan,
                    "coverage_conformal_int": np.nan,
                    "avg_width_conformal_int": np.nan,
                    "ci": float(cfg.gp_ci),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            ]
        )
        return per_unit, summary

    if bool(getattr(cfg, "pooled_loo_by_unit", False)):
        folds = [[int(u)] for u in unit_ids]
    else:
        n_folds = int(getattr(cfg, "pooled_unit_cv_folds", 5))
        folds = _make_unit_folds(unit_ids, n_folds=n_folds, seed=int(cfg.seed) + 77)

    rows = []
    for fold_id, test_units in enumerate(folds):
        test_units = [int(u) for u in test_units]
        train_units = [int(u) for u in unit_ids if int(u) not in set(test_units)]
        if len(train_units) < 2:
            continue

        # Optional routing model (DP-GMM) fit on training units only
        unit_modes = None
        mode_map: Dict[int, Tuple[int, float]] = {}
        resp_map: Dict[int, np.ndarray] = {}
        if mode_experts or use_mode_covariate:
            unit_modes = _infer_unit_modes_dpmm_fit_predict(
                work,
                train_unit_ids=train_units,
                all_unit_ids=unit_ids,
                K=int(cfg.K_init),
                seed=int(cfg.seed) + 1234 + int(fold_id),
                prefix_cycle_by_unit=obs_by_unit,
                max_points=int(getattr(cfg, "mode_infer_max_points", 20)),
                return_resp=bool(use_soft_expert),
            )
            if len(unit_modes) > 0:
                for _, r in unit_modes.iterrows():
                    mode_map[int(r["equipment_id"])] = (int(r["mode_hat"]), float(r["mode_prob"]))
                    if use_soft_expert:
                        resp_cols = [c for c in unit_modes.columns if c.startswith("resp_")]
                        if resp_cols:
                            resp_map[int(r["equipment_id"])] = r[resp_cols].to_numpy(dtype=float)

        # Build and fit pooled GPs
        # Global pooled GP (possibly with mode covariate appended)
        sub_all = work[work["equipment_id"].isin(train_units)].sort_values(["equipment_id", "cycle"])
        base_X = sub_all[["cycle", "temperature", "reuse_count"]].to_numpy(dtype=float)
        if use_mode_covariate:
            # Append inferred mode_hat as a constant per-unit covariate
            mode_feat = np.asarray([mode_map.get(int(uid), (0, 0.0))[0] for uid in sub_all["equipment_id"].to_numpy(dtype=int)], dtype=float)
            X_all = np.concatenate([base_X, mode_feat.reshape(-1, 1)], axis=1)
        else:
            X_all = base_X
        y_all = sub_all["performance"].to_numpy(dtype=float)
        gpr_global = _gpr_fit(X_all, y_all, seed=int(cfg.seed) + 9_999 + 31 * int(fold_id), cfg=cfg)

        # Expert GPs per mode (train units only)
        mode_to_gpr: Dict[int, GaussianProcessRegressor] = {}
        mode_to_nunits: Dict[int, int] = {}
        if mode_experts and unit_modes is not None and len(unit_modes) > 0:
            train_modes = unit_modes[unit_modes["equipment_id"].isin(train_units)].copy()
            for m, um in train_modes.groupby("mode_hat"):
                mu = um["equipment_id"].to_numpy(dtype=int)
                mode_to_nunits[int(m)] = int(len(mu))
                if int(len(mu)) < int(getattr(cfg, "pooled_mode_min_units", 5)):
                    continue
                sub_m = work[work["equipment_id"].isin([int(x) for x in mu.tolist()])].sort_values(["equipment_id", "cycle"])
                X_m = sub_m[["cycle", "temperature", "reuse_count"]].to_numpy(dtype=float)
                y_m = sub_m["performance"].to_numpy(dtype=float)
                mode_to_gpr[int(m)] = _gpr_fit(
                    X_m,
                    y_m,
                    seed=int(cfg.seed) + 10_000 + 97 * int(m) + 31 * int(fold_id),
                    cfg=cfg,
                )

        # Predict each test unit
        for equipment_id in test_units:
            fail_cycle = fail_by_unit.get(int(equipment_id), None)
            if fail_cycle is None or fail_cycle <= 3:
                continue
            obs_cycle = int(obs_by_unit.get(int(equipment_id), max(2, int(np.floor(obs_ratio * float(fail_cycle))))))
            true_rul = float(fail_cycle - obs_cycle)
            equip = work[work["equipment_id"] == int(equipment_id)].sort_values("cycle")
            equip_obs = equip[equip["cycle"] <= obs_cycle].copy()
            if len(equip_obs) < 5:
                continue

            # Routing info
            mode_hat, mode_prob = mode_map.get(int(equipment_id), (0, 0.0))
            n_units_expert = int(mode_to_nunits.get(int(mode_hat), 0))

            expert_used = False
            pred: Dict[str, float]
            if v == "global":
                pred = _predict_rul_from_prefit_gp(
                    gpr_global,
                    equip_obs,
                    cfg,
                    seed=int(cfg.seed) + 20_000 + int(equipment_id) + 31 * int(fold_id),
                )
            elif v == "mode_covariate":
                Xf_extra = (float(mode_hat),)
                # Reuse global GP but supply mode covariate at prediction time
                # (Design matrix builder handles constant extra features)
                # We call the underlying predict helper directly.
                Xf = _make_future_design_matrix(equip_obs, cfg, extra_const_features=Xf_extra)
                mu, cov = _gpr_predict_cov(gpr_global, Xf)
                rng = np.random.default_rng(int(cfg.seed) + 20_000 + int(equipment_id) + 31 * int(fold_id))
                mc = int(cfg.gp_mc_paths)
                if mc <= 0:
                    mc = 1
                y_paths = rng.multivariate_normal(mean=mu, cov=cov, size=mc)
                y_paths = np.asarray(y_paths, dtype=float)
                hits = y_paths <= float(cfg.gp_threshold)
                has_hit = hits.any(axis=1)
                first_hit = np.argmax(hits, axis=1)
                horizon = int(cfg.gp_max_future)
                rul_samples = np.where(has_hit, first_hit.astype(float), float(horizon))
                alpha = (1.0 - float(cfg.gp_ci)) / 2.0
                pred = {
                    "current_cycle": int(equip_obs["cycle"].iloc[-1]),
                    "rul_mean": float(np.mean(rul_samples)),
                    "rul_median": float(np.quantile(rul_samples, 0.5)),
                    "rul_lower": float(np.quantile(rul_samples, alpha)),
                    "rul_upper": float(np.quantile(rul_samples, 1.0 - alpha)),
                    "threshold": float(cfg.gp_threshold),
                }
            elif v == "hard_expert":
                gpr = mode_to_gpr.get(int(mode_hat), gpr_global)
                expert_used = bool(int(mode_hat) in mode_to_gpr)
                pred = _predict_rul_from_prefit_gp(
                    gpr,
                    equip_obs,
                    cfg,
                    seed=int(cfg.seed) + 20_000 + int(equipment_id) + 97 * int(mode_hat) + 31 * int(fold_id),
                )
            else:
                # soft_expert
                # Restrict weights to available experts, else fallback global
                if len(mode_to_gpr) == 0:
                    pred = _predict_rul_from_prefit_gp(
                        gpr_global,
                        equip_obs,
                        cfg,
                        seed=int(cfg.seed) + 20_000 + int(equipment_id) + 31 * int(fold_id),
                    )
                else:
                    resp = resp_map.get(int(equipment_id), None)
                    weights: Dict[int, float] = {}
                    if resp is not None and resp.size >= max(mode_to_gpr.keys()) + 1:
                        for mk in mode_to_gpr.keys():
                            weights[int(mk)] = float(resp[int(mk)])
                    else:
                        # Fallback: use argmax mode only
                        for mk in mode_to_gpr.keys():
                            weights[int(mk)] = 1.0 if int(mk) == int(mode_hat) else 0.0
                    pred = _predict_rul_from_mixture_of_prefit_gps(
                        experts=mode_to_gpr,
                        weights=weights,
                        equip_obs=equip_obs,
                        cfg=cfg,
                        seed=int(cfg.seed) + 30_000 + int(equipment_id) + 31 * int(fold_id),
                    )
                    expert_used = True

            lo = float(pred["rul_lower"])
            hi = float(pred["rul_upper"])
            mean = float(pred["rul_mean"])
            med = float(pred.get("rul_median", mean))

            rows.append(
                {
                    "equipment_id": int(equipment_id),
                    "cv_fold": int(fold_id),
                    "model": v,
                    "true_mode": int(equip_obs["true_mode"].iloc[-1]) if "true_mode" in equip_obs.columns else np.nan,
                    "mode_hat": int(mode_hat),
                    "mode_prob": float(mode_prob),
                    "expert_used": bool(expert_used),
                    "n_train_units_global": int(len(train_units)),
                    "n_train_units_expert": int(n_units_expert),
                    "fail_cycle": int(fail_cycle),
                    "obs_cycle": int(obs_cycle),
                    "true_rul": float(true_rul),
                    "pred_rul_mean": mean,
                    "pred_rul_median": med,
                    "pred_rul_lower": lo,
                    "pred_rul_upper": hi,
                    "abs_error_median": float(abs(med - true_rul)),
                    "sq_error_median": float((med - true_rul) ** 2),
                    "covered": bool((lo <= true_rul) and (true_rul <= hi)),
                    "interval_width": float(hi - lo),
                    "gp_convergence_warning_total": int(getattr(gpr_global, "_convergence_warning_count", 0))
                    if v in ("global", "mode_covariate")
                    else int(getattr(mode_to_gpr.get(int(mode_hat), gpr_global), "_convergence_warning_count", 0)),
                    "gp_convergence_warning_final": bool(getattr(gpr_global, "_convergence_warning_final", False))
                    if v in ("global", "mode_covariate")
                    else bool(getattr(mode_to_gpr.get(int(mode_hat), gpr_global), "_convergence_warning_final", False)),
                }
            )

    per_unit = pd.DataFrame(rows).sort_values(["obs_cycle", "equipment_id"]) if rows else pd.DataFrame()
    if len(per_unit) == 0:
        summary = pd.DataFrame(
            [
                {
                    "model": v,
                    "n_units": 0,
                    "mae": np.nan,
                    "rmse": np.nan,
                    "coverage_raw": np.nan,
                    "avg_width_raw": np.nan,
                    "coverage_conformal_int": np.nan,
                    "avg_width_conformal_int": np.nan,
                    "ci": float(cfg.gp_ci),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            ]
        )
        return per_unit, summary

    # Conformalize interval (LOO across units)
    true_all = per_unit["true_rul"].to_numpy(dtype=float)
    raw_lo = per_unit["pred_rul_lower"].to_numpy(dtype=float)
    raw_hi = per_unit["pred_rul_upper"].to_numpy(dtype=float)
    score_all = np.maximum.reduce([raw_lo - true_all, true_all - raw_hi, np.zeros_like(true_all)])
    n = int(len(per_unit))
    q_int_loo = np.full(n, np.nan, dtype=float)
    for i in range(n):
        others = np.delete(score_all, i)
        q_int_loo[i] = _conformal_q_from_abs_errors(others, ci=float(cfg.gp_ci))
    lo_int = raw_lo - q_int_loo
    hi_int = raw_hi + q_int_loo
    covered_int = (lo_int <= true_all) & (true_all <= hi_int)
    width_int = hi_int - lo_int
    per_unit["pred_rul_lower_conformal_int"] = lo_int
    per_unit["pred_rul_upper_conformal_int"] = hi_int
    per_unit["covered_conformal_int"] = covered_int
    per_unit["interval_width_conformal_int"] = width_int

    mae = float(per_unit["abs_error_median"].mean())
    rmse = float(np.sqrt(per_unit["sq_error_median"].mean()))
    coverage_raw = float(per_unit["covered"].mean())
    avg_width_raw = float(per_unit["interval_width"].mean())
    coverage_conformal_int = float(np.nanmean(covered_int.astype(float)))
    avg_width_conformal_int = float(np.nanmean(width_int))
    summary = pd.DataFrame(
        [
            {
                "model": v,
                "n_units": int(len(per_unit)),
                "mae": mae,
                "rmse": rmse,
                "coverage_raw": coverage_raw,
                "avg_width_raw": avg_width_raw,
                "coverage_conformal_int": coverage_conformal_int,
                "avg_width_conformal_int": avg_width_conformal_int,
                "ci": float(cfg.gp_ci),
                "obs_ratio": float(cfg.gp_obs_ratio),
            }
        ]
    )
    return per_unit, summary


def evaluate_gp_rul_coverage_pooled(
    degradation_df: pd.DataFrame,
    cfg: Config,
    outdir: Path,
    *,
    mode_experts: bool,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Evaluate pooled GP models (global vs mode-expert) for RUL with calibration.

    - mode_experts=False: single global GP trained on all observed points
    - mode_experts=True: infer per-unit modes, fit one GP per mode, pick expert by mode_hat
    """

    work = degradation_df.copy()
    if "temperature" not in work.columns:
        work["temperature"] = 0.0
    if "reuse_count" not in work.columns:
        work["reuse_count"] = 0.0

    # Precompute fail/obs cycles per unit (used both for prediction and leakage-safe mode inference)
    obs_ratio = float(cfg.gp_obs_ratio)
    fail_by_unit: Dict[int, int] = {}
    obs_by_unit: Dict[int, int] = {}
    for equipment_id in sorted(work["equipment_id"].unique()):
        fail_cycle = _first_failure_cycle(work, int(equipment_id))
        if fail_cycle is None:
            continue
        fail_by_unit[int(equipment_id)] = int(fail_cycle)
        obs_by_unit[int(equipment_id)] = max(2, int(np.floor(obs_ratio * float(fail_cycle))))

    unit_ids = [int(u) for u in sorted(work["equipment_id"].unique())]
    # Only keep units with known failure cycle (needed for true RUL)
    unit_ids = [u for u in unit_ids if int(u) in fail_by_unit]
    if len(unit_ids) == 0:
        per_unit = pd.DataFrame()
        summary = pd.DataFrame(
            [
                {
                    "model": "pooled_mode_expert" if mode_experts else "pooled_global",
                    "n_units": 0,
                    "mae": np.nan,
                    "rmse": np.nan,
                    "coverage_raw": np.nan,
                    "avg_width_raw": np.nan,
                    "coverage_conformal_int": np.nan,
                    "avg_width_conformal_int": np.nan,
                    "ci": float(cfg.gp_ci),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            ]
        )
        return per_unit, summary

    if bool(getattr(cfg, "pooled_loo_by_unit", False)):
        folds = [[int(u)] for u in unit_ids]
    else:
        n_folds = int(getattr(cfg, "pooled_unit_cv_folds", 5))
        folds = _make_unit_folds(unit_ids, n_folds=n_folds, seed=int(cfg.seed) + 77)

    rows = []
    # fold-wise evaluation: train models on train units, predict on test units
    for fold_id, test_units in enumerate(folds):
        test_units = [int(u) for u in test_units]
        train_units = [int(u) for u in unit_ids if int(u) not in set(test_units)]
        if len(train_units) < 2:
            continue

        # Fit global pooled GP on training units only
        sub_all = work[work["equipment_id"].isin(train_units)].sort_values(["equipment_id", "cycle"])
        X_all = sub_all[["cycle", "temperature", "reuse_count"]].to_numpy(dtype=float)
        y_all = sub_all["performance"].to_numpy(dtype=float)
        gpr_global = _gpr_fit(X_all, y_all, seed=int(cfg.seed) + 9_999 + 31 * int(fold_id), cfg=cfg)

        # Fit DP-GMM on training units (prefix-aligned) and predict modes for all units
        unit_modes = None
        mode_map: Dict[int, Tuple[int, float]] = {}
        if mode_experts:
            unit_modes = _infer_unit_modes_dpmm_fit_predict(
                work,
                train_unit_ids=train_units,
                all_unit_ids=unit_ids,
                K=int(cfg.K_init),
                seed=int(cfg.seed) + 1234 + int(fold_id),
                prefix_cycle_by_unit=obs_by_unit,
                max_points=int(getattr(cfg, "mode_infer_max_points", 20)),
            )
            for _, r in unit_modes.iterrows():
                mode_map[int(r["equipment_id"])] = (int(r["mode_hat"]), float(r["mode_prob"]))

        # Fit expert GPs per mode using training units only
        mode_to_gpr: Dict[int, GaussianProcessRegressor] = {}
        mode_to_nunits: Dict[int, int] = {}
        if mode_experts and unit_modes is not None and len(unit_modes) > 0:
            # Determine training units by predicted mode
            train_modes = unit_modes[unit_modes["equipment_id"].isin(train_units)].copy()
            for m, um in train_modes.groupby("mode_hat"):
                mu = um["equipment_id"].to_numpy(dtype=int)
                mode_to_nunits[int(m)] = int(len(mu))
                if int(len(mu)) < int(getattr(cfg, "pooled_mode_min_units", 5)):
                    continue
                sub_m = work[work["equipment_id"].isin([int(x) for x in mu.tolist()])].sort_values(["equipment_id", "cycle"])
                X_m = sub_m[["cycle", "temperature", "reuse_count"]].to_numpy(dtype=float)
                y_m = sub_m["performance"].to_numpy(dtype=float)
                mode_to_gpr[int(m)] = _gpr_fit(
                    X_m,
                    y_m,
                    seed=int(cfg.seed) + 10_000 + 97 * int(m) + 31 * int(fold_id),
                    cfg=cfg,
                )

        # Predict each test unit using the appropriate model
        for equipment_id in test_units:
            fail_cycle = fail_by_unit.get(int(equipment_id), None)
            if fail_cycle is None or fail_cycle <= 3:
                continue
            obs_cycle = int(obs_by_unit.get(int(equipment_id), max(2, int(np.floor(obs_ratio * float(fail_cycle))))))
            true_rul = float(fail_cycle - obs_cycle)
            equip = work[work["equipment_id"] == int(equipment_id)].sort_values("cycle")
            equip_obs = equip[equip["cycle"] <= obs_cycle].copy()
            if len(equip_obs) < 5:
                continue

            expert_used = False
            n_units_expert = 0
            if mode_experts:
                mode_hat, mode_prob = mode_map.get(int(equipment_id), (0, 0.0))
                n_units_expert = int(mode_to_nunits.get(int(mode_hat), 0))
                gpr = mode_to_gpr.get(int(mode_hat), gpr_global)
                expert_used = bool(int(mode_hat) in mode_to_gpr)
            else:
                mode_hat, mode_prob = 0, 1.0
                gpr = gpr_global

            pred = _predict_rul_from_prefit_gp(
                gpr=gpr,
                equip_obs=equip_obs,
                cfg=cfg,
                seed=int(cfg.seed) + 20_000 + int(equipment_id) + 97 * int(mode_hat) + 31 * int(fold_id),
            )
            lo = float(pred["rul_lower"])
            hi = float(pred["rul_upper"])
            mean = float(pred["rul_mean"])
            med = float(pred.get("rul_median", mean))

            rows.append(
                {
                    "equipment_id": int(equipment_id),
                    "cv_fold": int(fold_id),
                    "true_mode": int(equip_obs["true_mode"].iloc[-1]) if "true_mode" in equip_obs.columns else np.nan,
                    "mode_hat": int(mode_hat),
                    "mode_prob": float(mode_prob),
                    "expert_used": bool(expert_used),
                    "n_train_units_global": int(len(train_units)),
                    "n_train_units_expert": int(n_units_expert),
                    "fail_cycle": int(fail_cycle),
                    "obs_cycle": int(obs_cycle),
                    "true_rul": float(true_rul),
                    "pred_rul_mean": mean,
                    "pred_rul_median": med,
                    "pred_rul_lower": lo,
                    "pred_rul_upper": hi,
                    "abs_error_median": float(abs(med - true_rul)),
                    "sq_error_median": float((med - true_rul) ** 2),
                    "covered": bool((lo <= true_rul) and (true_rul <= hi)),
                    "interval_width": float(hi - lo),
                    "gp_convergence_warning_total": int(getattr(gpr, "_convergence_warning_count", 0)),
                    "gp_convergence_warning_final": bool(getattr(gpr, "_convergence_warning_final", False)),
                    "gp_kernel_any_bound_hit": int(getattr(gpr, "_kernel_bound_hits", {}).get("any_hit", 0)),
                    "gp_kernel_n_bound_hit": int(getattr(gpr, "_kernel_bound_hits", {}).get("n_hit", 0)),
                }
            )

    if mode_experts and len(rows) > 0:
        # Keep one artifact: mode assignment from the first fold (for auditability)
        try:
            if "unit_modes" in locals() and unit_modes is not None and len(unit_modes) > 0:
                unit_modes.to_csv(outdir / "degradation_unit_modes_dp_gmm.csv", index=False)
        except Exception:
            pass

    per_unit = pd.DataFrame(rows).sort_values("equipment_id")
    if len(per_unit) == 0:
        summary = pd.DataFrame(
            [
                {
                    "model": "pooled_mode_expert" if mode_experts else "pooled_global",
                    "n_units": 0,
                    "mae": np.nan,
                    "rmse": np.nan,
                    "coverage_raw": np.nan,
                    "avg_width_raw": np.nan,
                    "coverage_conformal_int": np.nan,
                    "avg_width_conformal_int": np.nan,
                    "ci": float(cfg.gp_ci),
                    "obs_ratio": float(cfg.gp_obs_ratio),
                }
            ]
        )
        return per_unit, summary

    mae = float(per_unit["abs_error_median"].mean())
    rmse = float(np.sqrt(per_unit["sq_error_median"].mean()))
    coverage_raw = float(per_unit["covered"].mean())
    avg_width_raw = float(per_unit["interval_width"].mean())

    # CQR-style conformalization of the interval itself (LOO over units)
    true_all = per_unit["true_rul"].to_numpy(dtype=float)
    raw_lo = per_unit["pred_rul_lower"].to_numpy(dtype=float)
    raw_hi = per_unit["pred_rul_upper"].to_numpy(dtype=float)
    score_all = np.maximum.reduce([raw_lo - true_all, true_all - raw_hi, np.zeros_like(true_all)])
    n = int(len(per_unit))
    q_int_loo = np.full(n, np.nan, dtype=float)
    for i in range(n):
        others = np.delete(score_all, i)
        q_int_loo[i] = _conformal_q_from_abs_errors(others, ci=float(cfg.gp_ci))
    lo_int = raw_lo - q_int_loo
    hi_int = raw_hi + q_int_loo
    covered_int = (lo_int <= true_all) & (true_all <= hi_int)
    width_int = hi_int - lo_int

    per_unit["pred_rul_lower_conformal_int"] = lo_int
    per_unit["pred_rul_upper_conformal_int"] = hi_int
    per_unit["covered_conformal_int"] = covered_int
    per_unit["interval_width_conformal_int"] = width_int

    coverage_conformal_int = float(np.nanmean(covered_int.astype(float)))
    avg_width_conformal_int = float(np.nanmean(width_int))

    summary = pd.DataFrame(
        [
            {
                "model": "pooled_mode_expert" if mode_experts else "pooled_global",
                "n_units": int(len(per_unit)),
                "mae": mae,
                "rmse": rmse,
                "coverage_raw": coverage_raw,
                "avg_width_raw": avg_width_raw,
                "coverage_conformal_int": coverage_conformal_int,
                "avg_width_conformal_int": avg_width_conformal_int,
                "ci": float(cfg.gp_ci),
                "obs_ratio": float(cfg.gp_obs_ratio),
            }
        ]
    )
    return per_unit, summary


def evaluate_gp_rul_coverage_pooled_multi(
    degradation_df: pd.DataFrame,
    base_cfg: Config,
    outdir: Path,
    *,
    obs_ratios: Tuple[float, ...],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Run pooled GP (global vs mode-expert) across multiple observation ratios.

    Returns:
      per_unit_all: concatenated per-unit rows with columns [obs_ratio, model, ...]
      summary_all: concatenated summary rows with columns [obs_ratio, model, ...]
    """

    per_unit_rows = []
    summary_rows = []
    for r in obs_ratios:
        cfg = replace(base_cfg, gp_obs_ratio=float(r))
        for mode_experts in (False, True):
            per_unit, summary = evaluate_gp_rul_coverage_pooled(
                degradation_df=degradation_df,
                cfg=cfg,
                outdir=outdir,
                mode_experts=mode_experts,
            )
            if len(per_unit) > 0:
                per_unit = per_unit.copy()
                per_unit["obs_ratio"] = float(r)
                per_unit["model"] = "pooled_mode_expert" if mode_experts else "pooled_global"
                per_unit_rows.append(per_unit)
            if len(summary) > 0:
                s = summary.copy()
                s["obs_ratio"] = float(r)
                summary_rows.append(s)

    per_unit_all = pd.concat(per_unit_rows, axis=0, ignore_index=True) if per_unit_rows else pd.DataFrame()
    summary_all = pd.concat(summary_rows, axis=0, ignore_index=True) if summary_rows else pd.DataFrame()
    return per_unit_all, summary_all


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--outdir", type=str, default=str(Path("results") / "paper_demo"))
    ap.add_argument("--quick", action="store_true", help="fewer iterations for a fast sanity run")
    ap.add_argument("--n-failure-samples", type=int, default=200)
    ap.add_argument("--n-degradation-units", type=int, default=25)
    ap.add_argument("--max-cycles", type=int, default=60)
    ap.add_argument("--history-strength", type=int, default=0)
    ap.add_argument("--expert-strength", type=int, default=0)

    # GP robustness/fit controls
    ap.add_argument(
        "--gp-n-restarts",
        type=int,
        default=10,
        help="GP hyperparameter optimizer restarts (higher => more stable, slower)",
    )
    ap.add_argument(
        "--gp-kernel-family",
        type=str,
        default="matern+rbf",
        help="GP kernel family: matern | rbf | matern+rbf | matern+rbf+periodic",
    )
    ap.add_argument(
        "--gp-model-selection",
        type=str,
        default="lml",
        help="GP model selection: lml (log-marginal likelihood) | holdout (time holdout RMSE)",
    )
    ap.add_argument("--gp-holdout-frac", type=float, default=0.25)
    ap.add_argument("--gp-holdout-min-points", type=int, default=3)
    ap.add_argument("--gp-holdout-max-points", type=int, default=10)
    ap.add_argument("--gp-holdout-min-total", type=int, default=8)

    # Robustness evaluation
    ap.add_argument("--repeats", type=int, default=1, help="number of random-seed repeats for robustness")
    ap.add_argument(
        "--obs-ratios",
        type=str,
        default="0.7",
        help="comma-separated observation ratios for GP-RUL evaluation (e.g., 0.5,0.7,0.9)",
    )

    # NASA C-MAPSS
    ap.add_argument("--run-nasa", action="store_true", help="run NASA C-MAPSS public dataset validation")
    ap.add_argument("--nasa-dir", type=str, default=str(Path("data") / "nasa_cmapss"))
    ap.add_argument("--nasa-subset", type=str, default="FD001")
    ap.add_argument("--nasa-max-future", type=int, default=400)
    ap.add_argument(
        "--nasa-gp-mc-paths",
        type=int,
        default=0,
        help="if >0, run NASA train-unit GP interval evaluation with this many MC paths",
    )
    ap.add_argument("--nasa-gp-ci", type=float, default=0.90, help="nominal interval level for NASA GP evaluation")
    args = ap.parse_args()

    cfg = Config(
        seed=int(args.seed),
        n_failure_samples=int(args.n_failure_samples),
        n_degradation_units=int(args.n_degradation_units),
        max_cycles=int(args.max_cycles),
        history_strength=int(args.history_strength),
        expert_strength=int(args.expert_strength),
        nasa_max_future=int(args.nasa_max_future),
        nasa_gp_ci=float(args.nasa_gp_ci),
        nasa_gp_mc_paths=int(args.nasa_gp_mc_paths),
        gp_n_restarts=int(args.gp_n_restarts),
        gp_kernel_family=str(args.gp_kernel_family),
        gp_model_selection=str(args.gp_model_selection),
        gp_holdout_frac=float(args.gp_holdout_frac),
        gp_holdout_min_points=int(args.gp_holdout_min_points),
        gp_holdout_max_points=int(args.gp_holdout_max_points),
        gp_holdout_min_total=int(args.gp_holdout_min_total),
    )

    if args.quick:
        cfg.nLap = 60
        cfg.bootstrap = 80
        cfg.gp_mc_paths = 120
        cfg.gp_max_future = 80

    _set_seed(cfg.seed)
    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    if args.run_nasa:
        nasa_dir = Path(args.nasa_dir)
        run_nasa_cmapss_validation(cfg=cfg, nasa_dir=nasa_dir, subset=str(args.nasa_subset), outdir=outdir)
        print("\nNASA validation complete.")
        return

    # 1) Generate simulated datasets
    from cryogenic_reliability_data_generator import CryogenicEquipmentDataGenerator

    gen = CryogenicEquipmentDataGenerator(random_seed=cfg.seed)
    failure_df = gen.generate_failure_data(n_samples=cfg.n_failure_samples, include_censored=cfg.include_censored)
    # For GP-RUL evaluation we define failure by the health indicator (performance)
    # to match the GP model (which does not explicitly model crack-length failure).
    degradation_df = gen.generate_degradation_data(
        n_equipment=cfg.n_degradation_units,
        max_cycles=cfg.max_cycles,
        include_crack_failure=False,
    )

    n_failure_original = int(len(failure_df))

    # Optional multi-source fusion (history/expert)
    history_df = None
    failure_df = _augment_with_history(failure_df, history_df=history_df, strength=cfg.history_strength)
    failure_df = _augment_with_expert(failure_df, strength=cfg.expert_strength)

    failure_csv = outdir / "failure_data_used.csv"
    degr_csv = outdir / "degradation_data_used.csv"
    failure_df.to_csv(failure_csv, index=False)
    degradation_df.to_csv(degr_csv, index=False)

    print("=" * 80)
    print("BNP Cryogenic Reliability Demo")
    print("=" * 80)
    print(f"Failure samples: {len(failure_df)} (failed={(~failure_df['is_censored']).sum()}, censored={failure_df['is_censored'].sum()})")
    print(f"Degradation units: {degradation_df['equipment_id'].nunique()} | points={len(degradation_df)}")
    print(f"Outputs: {outdir}")

    # Optional robustness sweep (runs additional simulations; writes summary CSV/plot)
    try:
        obs_ratios = tuple(float(x.strip()) for x in str(args.obs_ratios).split(",") if x.strip())
    except Exception:
        obs_ratios = (0.7,)
    repeats = int(getattr(args, "repeats", 1))
    if repeats > 1 or len(obs_ratios) > 1:
        print("\nRunning GP-RUL robustness sweep...")
        _, agg = run_gp_rul_robustness(base_cfg=cfg, repeats=repeats, obs_ratios=obs_ratios, outdir=outdir)
        if len(agg) > 0:
            print("[robustness] wrote rul_robustness_runs.csv, rul_robustness_summary.csv, rul_robustness.png")

    # 2) DPMM failure-mode discovery
    Xz, feat_cols = _select_features_for_dpmm(failure_df)
    model, info, labels, resp = fit_dpmm_sklearn(Xz, K=cfg.K_init, seed=cfg.seed)

    failure_df = failure_df.copy()
    failure_df["mode_hat"] = labels
    failure_df["mode_prob"] = resp[np.arange(resp.shape[0]), labels]

    # Save a version that includes inferred modes and confidence.
    failure_df.to_csv(outdir / "failure_data_with_modes.csv", index=False)

    n_modes = len(np.unique(labels))
    print(f"DPMM inferred modes: {n_modes} (truncation K={cfg.K_init})")
    try:
        print(f"DP-VB converged={info.get('converged')} iters={info.get('n_iter')} lower_bound={info.get('lower_bound'):.3f}")
    except Exception:
        pass

    # DPMM recovery (simulation only; excludes pseudo-samples)
    if "true_mode" in failure_df.columns:
        mask_real = failure_df["sample_id"].to_numpy(dtype=int) < int(n_failure_original)
        y_true = failure_df.loc[mask_real, "true_mode"].to_numpy(dtype=int)
        y_hat = failure_df.loc[mask_real, "mode_hat"].to_numpy(dtype=int)
        ari = float(adjusted_rand_score(y_true, y_hat))
        nmi = float(normalized_mutual_info_score(y_true, y_hat))
        rec = pd.DataFrame([
            {
                "n": int(mask_real.sum()),
                "ari": ari,
                "nmi": nmi,
                "K_trunc": int(cfg.K_init),
                "history_strength": int(cfg.history_strength),
                "expert_strength": int(cfg.expert_strength),
            }
        ])
        rec.to_csv(outdir / "dpmm_mode_recovery.csv", index=False)

        ct = pd.crosstab(
            pd.Series(y_true, name="true_mode"),
            pd.Series(y_hat, name="mode_hat"),
        )
        ct.to_csv(outdir / "dpmm_contingency_true_vs_hat.csv")

        # Baseline clustering comparisons (KMeans/GMM-BIC) to contextualize ARI/NMI
        try:
            baselines = compute_clustering_baselines(Xz=Xz[mask_real], y_true=y_true, seed=cfg.seed, K_trunc=cfg.K_init)
            baselines.to_csv(outdir / "clustering_baselines_ari_nmi.csv", index=False)
        except Exception as e:
            print(f"[baseline] clustering baseline comparison skipped: {e}")

    # 3) Nonparametric reliability via KM per inferred mode (uses censoring)
    max_t = float(failure_df["time_to_failure"].max())
    time_grid = np.linspace(0.0, max_t * 1.05, int(cfg.n_time_grid))

    mode_rows = []
    km_curves: Dict[int, Dict[str, np.ndarray]] = {}
    for m in sorted(np.unique(labels)):
        sub = failure_df[failure_df["mode_hat"] == m]
        times = sub["time_to_failure"].to_numpy(dtype=float)
        events = (~sub["is_censored"].astype(bool)).to_numpy(dtype=int)

        S_mid, S_lo, S_hi = km_bootstrap_ci(
            times=times,
            events=events,
            time_grid=time_grid,
            n_boot=cfg.bootstrap,
            ci=cfg.ci,
            seed=cfg.seed + 1000 + int(m),
        )
        km_curves[int(m)] = {"S": S_mid, "S_lo": S_lo, "S_hi": S_hi}

        # Simple summary points
        def _interp_at(t0: float, arr: np.ndarray) -> float:
            return float(np.interp(t0, time_grid, arr))

        mode_rows.append(
            {
                "mode_hat": int(m),
                "n": int(len(sub)),
                "n_failed": int(events.sum()),
                "n_censored": int(len(sub) - events.sum()),
                "mean_mode_prob": float(sub["mode_prob"].mean()),
                "R_t25": _interp_at(25.0, S_mid),
                "R_t50": _interp_at(50.0, S_mid),
                "R_t75": _interp_at(75.0, S_mid),
            }
        )

    summary_df = pd.DataFrame(mode_rows).sort_values("mode_hat")
    summary_csv = outdir / "mode_reliability_summary.csv"
    summary_df.to_csv(summary_csv, index=False)

    print("\nMode reliability summary (KM):")
    print(summary_df)

    # 4) GP degradation + RUL evaluation (interval coverage) on simulated units
    per_unit_gp, gp_summary = evaluate_gp_rul_coverage(degradation_df, cfg=cfg, outdir=outdir)
    print("\nGP RUL coverage summary:")
    print(gp_summary)
    try:
        row0 = gp_summary.iloc[0]
        print(
            f"[GP] raw_coverage={float(row0.get('coverage_raw', row0.get('coverage'))):.3f} "
            f"conformal_int_coverage={float(row0.get('coverage_conformal_int', np.nan)):.3f} "
            f"raw_width={float(row0.get('avg_width_raw', row0.get('avg_width'))):.2f} "
            f"conformal_int_width={float(row0.get('avg_width_conformal_int', np.nan)):.2f}"
        )
    except Exception:
        pass

    # 4b) Optional coupling: mode-aware pooled GP experts for RUL
    try:
        # Use the same obs-ratio grid as the robustness sweep if provided.
        obs_ratios_for_pooled = tuple(float(x) for x in obs_ratios) if isinstance(obs_ratios, tuple) else (float(cfg.gp_obs_ratio),)
        per_unit_all, pooled_summary = evaluate_gp_rul_coverage_pooled_multi(
            degradation_df=degradation_df,
            base_cfg=cfg,
            outdir=outdir,
            obs_ratios=obs_ratios_for_pooled,
        )

        if len(per_unit_all) > 0:
            per_unit_all.to_csv(outdir / "gp_rul_pooled_by_unit.csv", index=False)

        pooled_summary.to_csv(outdir / "gp_rul_pooled_summary.csv", index=False)

        print("\nPooled GP summary (global vs mode-expert) across ratios:")
        print(pooled_summary.sort_values(["obs_ratio", "model"]))
    except Exception as e:
        print(f"[mode-aware] pooled GP expert evaluation skipped: {e}")

    # Also report one representative unit for visualization
    unit_lengths = degradation_df.groupby("equipment_id")["cycle"].max().sort_values()
    pick = int(unit_lengths.index[len(unit_lengths) // 2])
    gp_result = fit_gp_and_rul(degradation_df, equipment_id=pick, cfg=cfg)
    gp_csv = outdir / "gp_rul_result.csv"
    pd.DataFrame([gp_result]).to_csv(gp_csv, index=False)

    # 5) Plots (optional)
    plt = _try_import_matplotlib()
    if plt is not None:
        # Optional: keep a separate folder with paper-ready B/W figures
        esrel_bw_dir = outdir / "figures_bw"
        try:
            esrel_bw_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            esrel_bw_dir = None

        # 5.1 PCA scatter of inferred modes
        try:
            from sklearn.decomposition import PCA

            pca = PCA(n_components=2)
            Z = pca.fit_transform(Xz)

            # Encode confidence via marker size for a more meaningful plot.
            if "mode_prob" in failure_df.columns:
                conf = failure_df["mode_prob"].to_numpy(dtype=float)
                conf = np.clip(conf, 0.0, 1.0)
            else:
                conf = np.ones(len(labels), dtype=float)

            sizes = 10.0 + 70.0 * conf
            alpha0 = 0.75

            markers = ["o", "s", "^", "D", "v", "P", "X", "+", "x"]
            modes = sorted(set(int(x) for x in labels.tolist()))

            fig, ax = plt.subplots(figsize=(7.5, 5.8))
            # Black-and-white friendly: differentiate modes by marker shape (not color).
            for i, m in enumerate(modes):
                mk = markers[i % len(markers)]
                mask = labels == int(m)
                ax.scatter(
                    Z[mask, 0],
                    Z[mask, 1],
                    s=sizes[mask],
                    marker=mk,
                    facecolors="none",
                    edgecolors="black",
                    linewidths=0.9,
                    alpha=alpha0,
                    label=f"Mode {m}",
                )
            ax.set_title("Failure-mode discovery (DP mixture; PCA projection)")
            ax.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)")
            ax.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)")
            ax.grid(True, alpha=0.25)
            ax.legend(loc="best", frameon=True, fontsize=9)

            fig.tight_layout()
            fig.savefig(outdir / "dpmm_modes_pca.png", dpi=160)
            plt.close(fig)
        except Exception as e:
            print(f"[demo] PCA plot skipped: {e}")

        # 5.1b DPMM effect: true_mode vs inferred mode_hat (simulation only)
        # This is often the clearest figure for explaining what the mixture did.
        try:
            if "true_mode" in failure_df.columns:
                # Exclude pseudo-samples if present
                mask_real = failure_df["sample_id"].to_numpy(dtype=int) < int(n_failure_original)
                y_true = failure_df.loc[mask_real, "true_mode"].to_numpy(dtype=int)
                y_hat = failure_df.loc[mask_real, "mode_hat"].to_numpy(dtype=int)

                ct = pd.crosstab(pd.Series(y_true, name="true_mode"), pd.Series(y_hat, name="mode_hat"))
                mat = ct.to_numpy(dtype=float)

                fig, ax = plt.subplots(figsize=(7.8, 4.6))
                im = ax.imshow(mat, cmap="Greys", aspect="auto")
                ax.set_title("DPMM mode discovery: true mechanisms vs inferred clusters")
                ax.set_xlabel("Inferred mode (mode_hat)")
                ax.set_ylabel("True mode (simulation label)")
                ax.set_xticks(np.arange(ct.shape[1]))
                ax.set_xticklabels([str(c) for c in ct.columns])
                ax.set_yticks(np.arange(ct.shape[0]))
                ax.set_yticklabels([str(i) for i in ct.index])

                # Annotate counts
                vmax = float(np.nanmax(mat)) if mat.size else 1.0
                for i in range(mat.shape[0]):
                    for j in range(mat.shape[1]):
                        val = int(mat[i, j])
                        if val == 0:
                            continue
                        # Use white text on dark cells for readability
                        color = "white" if vmax > 0 and (mat[i, j] / vmax) > 0.55 else "black"
                        ax.text(j, i, str(val), ha="center", va="center", fontsize=9, color=color)

                fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="Count")
                fig.tight_layout()
                fig.savefig(outdir / "dpmm_true_vs_hat_heatmap.png", dpi=160)

                if esrel_bw_dir is not None:
                    fig.savefig(esrel_bw_dir / "fig2_true_vs_hat_heatmap.png", dpi=300)
                plt.close(fig)
        except Exception as e:
            print(f"[demo] DPMM heatmap skipped: {e}")

        # 5.1c DPMM effect: cluster size and average assignment confidence
        try:
            if "mode_hat" in failure_df.columns and "mode_prob" in failure_df.columns:
                grp = (
                    failure_df.groupby("mode_hat")
                    .agg(n=("mode_hat", "size"), mean_conf=("mode_prob", "mean"))
                    .reset_index()
                    .sort_values("mode_hat")
                )
                fig, ax1 = plt.subplots(figsize=(7.8, 4.0))
                x = np.arange(len(grp))
                ax1.bar(
                    x,
                    grp["n"].to_numpy(dtype=float),
                    alpha=0.90,
                    color="0.75",
                    edgecolor="black",
                    linewidth=1.0,
                    label="#samples",
                    hatch="//",
                )
                ax1.set_xticks(x)
                ax1.set_xticklabels([str(int(v)) for v in grp["mode_hat"].to_numpy(dtype=int)])
                ax1.set_xlabel("Inferred mode (mode_hat)")
                ax1.set_ylabel("#samples")
                ax1.grid(True, axis="y", alpha=0.25)

                ax2 = ax1.twinx()
                ax2.plot(x, grp["mean_conf"].to_numpy(dtype=float), "o-", color="black", label="avg confidence")
                ax2.set_ylim(0.0, 1.05)
                ax2.set_ylabel("Avg assignment confidence (mode_prob)")

                ax1.set_title("DPMM cluster summary: size and confidence")
                # Combined legend
                ax1.legend(loc="upper left")
                ax2.legend(loc="upper right")
                fig.tight_layout()
                fig.savefig(outdir / "dpmm_cluster_size_confidence.png", dpi=160)
                plt.close(fig)
        except Exception as e:
            print(f"[demo] DPMM size/confidence plot skipped: {e}")

        # 5.2 KM reliability curves with CI bands
        fig, ax = plt.subplots(figsize=(8.0, 5.5))
        linestyles = ["-", "--", "-.", ":"]
        markers = ["o", "s", "^", "D", "v", "P", "X", "+", "x"]
        for i, (m, cur) in enumerate(sorted(km_curves.items(), key=lambda z: int(z[0]))):
            ax.plot(
                time_grid,
                cur["S"],
                linewidth=2,
                color="black",
                linestyle=linestyles[i % len(linestyles)],
                marker=markers[i % len(markers)],
                markevery=max(1, int(len(time_grid) // 12)),
                markersize=5,
                label=f"mode {m}",
            )
            ax.fill_between(time_grid, cur["S_lo"], cur["S_hi"], alpha=0.20, color="0.7", linewidth=0)
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("Time (cycles)")
        ax.set_ylabel("Reliability $R(t)$")
        ax.set_title(f"Nonparametric reliability by inferred mode (Kaplan–Meier, {int(cfg.ci*100)}% CI)")
        ax.grid(True, alpha=0.25)
        ax.legend(loc="best")
        fig.tight_layout()
        fig.savefig(outdir / "km_reliability_by_mode.png", dpi=160)
        plt.close(fig)

        # 5.3 Degradation trajectory for selected unit
        sub = degradation_df[degradation_df["equipment_id"] == pick].sort_values("cycle")
        fig, ax = plt.subplots(figsize=(8.0, 5.0))
        ax.plot(sub["cycle"], sub["performance"], "o-", markersize=4, linewidth=1.5, label="observed")
        ax.axhline(cfg.gp_threshold, color="k", linestyle="--", linewidth=1.5, label="threshold")
        ax.set_xlabel("Cycle")
        ax.set_ylabel("Health indicator (performance)")
        ax.set_title(
            f"Degradation trajectory (unit {pick}) | RUL={gp_result['rul_mean']:.1f} cycles, {int(cfg.gp_ci*100)}% PI=[{gp_result['rul_lower']:.1f},{gp_result['rul_upper']:.1f}]"
        )
        ax.grid(True, alpha=0.25)
        ax.legend(loc="best")
        fig.tight_layout()
        fig.savefig(outdir / "degradation_example.png", dpi=160)

        if esrel_bw_dir is not None:
            fig.savefig(esrel_bw_dir / "fig4_degradation_example.png", dpi=300)
        plt.close(fig)

        # 5.4 GP RUL prediction vs true with error bars (simulation)
        if len(per_unit_gp) > 0:
            fig, ax = plt.subplots(figsize=(6.4, 6.0))
            x = per_unit_gp["true_rul"].to_numpy(dtype=float)
            y = per_unit_gp["pred_rul_mean"].to_numpy(dtype=float)
            ylo = per_unit_gp["pred_rul_lower"].to_numpy(dtype=float)
            yhi = per_unit_gp["pred_rul_upper"].to_numpy(dtype=float)
            yerr_lo = np.maximum(0.0, y - ylo)
            yerr_hi = np.maximum(0.0, yhi - y)
            ax.errorbar(x, y, yerr=[yerr_lo, yerr_hi], fmt="o", markersize=4, alpha=0.6, linewidth=1.0)
            for ln in ax.lines:
                ln.set_color("black")
            lim = max(float(np.max(x)), float(np.max(y)), 1.0)
            ax.plot([0, lim], [0, lim], "k--", linewidth=1.5)
            ax.set_xlabel("True RUL (cycles)")
            ax.set_ylabel(f"Predicted RUL (cycles; mean ± {int(cfg.gp_ci*100)}% PI)")
            ax.set_title(f"GP RUL prediction (raw interval; coverage={float(per_unit_gp['covered'].mean()):.2f})")
            ax.grid(True, alpha=0.25)
            fig.tight_layout()
            fig.savefig(outdir / "gp_rul_pred_vs_true.png", dpi=160)
            plt.close(fig)

            # 5.5 Same scatter but with conformalized intervals (CQR-style)
            if {
                "pred_rul_lower_conformal_int",
                "pred_rul_upper_conformal_int",
                "covered_conformal_int",
                "pred_rul_median",
            }.issubset(set(per_unit_gp.columns)):
                fig, ax = plt.subplots(figsize=(6.4, 6.0))
                y = per_unit_gp["pred_rul_median"].to_numpy(dtype=float)
                ylo = per_unit_gp["pred_rul_lower_conformal_int"].to_numpy(dtype=float)
                yhi = per_unit_gp["pred_rul_upper_conformal_int"].to_numpy(dtype=float)
                yerr_lo = np.maximum(0.0, y - ylo)
                yerr_hi = np.maximum(0.0, yhi - y)
                ax.errorbar(x, y, yerr=[yerr_lo, yerr_hi], fmt="o", markersize=4, alpha=0.6, linewidth=1.0)
                for ln in ax.lines:
                    ln.set_color("black")
                lim = max(float(np.max(x)), float(np.max(y)), 1.0)
                ax.plot([0, lim], [0, lim], "k--", linewidth=1.5)
                cov = float(per_unit_gp["covered_conformal_int"].mean())
                ax.set_xlabel("True RUL (cycles)")
                ax.set_ylabel(f"Predicted RUL (cycles; median ± calibrated {int(cfg.gp_ci*100)}% PI)")
                ax.set_title(f"GP RUL prediction (conformal-calibrated; coverage={cov:.2f})")
                ax.grid(True, alpha=0.25)
                fig.tight_layout()
                fig.savefig(outdir / "gp_rul_pred_vs_true_conformal.png", dpi=160)
                plt.close(fig)

            # 5.6 Coverage/width comparison bar chart
            try:
                cov_raw = float(per_unit_gp["covered"].mean())
                width_raw = float((per_unit_gp["pred_rul_upper"] - per_unit_gp["pred_rul_lower"]).mean())
                cov_c = float(per_unit_gp["covered_conformal_int"].mean()) if "covered_conformal_int" in per_unit_gp.columns else np.nan
                width_c = (
                    float((per_unit_gp["pred_rul_upper_conformal_int"] - per_unit_gp["pred_rul_lower_conformal_int"]).mean())
                    if {
                        "pred_rul_lower_conformal_int",
                        "pred_rul_upper_conformal_int",
                    }.issubset(set(per_unit_gp.columns))
                    else np.nan
                )

                fig, ax = plt.subplots(figsize=(7.2, 4.0))
                ax2 = ax.twinx()
                labels = ["Raw", "Conformal"]
                x0 = np.arange(len(labels))
                w = 0.35

                b1 = ax.bar(
                    x0 - w / 2,
                    [cov_raw, cov_c],
                    width=w,
                    label="Empirical coverage",
                    alpha=0.95,
                    color="0.65",
                    edgecolor="black",
                    linewidth=1.0,
                    hatch="//",
                )
                b2 = ax2.bar(
                    x0 + w / 2,
                    [width_raw, width_c],
                    width=w,
                    label="Avg interval width (cycles)",
                    alpha=0.95,
                    color="0.85",
                    edgecolor="black",
                    linewidth=1.0,
                    hatch="..",
                )

                ax.set_xticks(x0)
                ax.set_xticklabels(labels)
                ax.set_ylim(0.0, 1.05)
                ax.set_ylabel("Coverage")
                ax2.set_ylabel("Avg interval width (cycles)")
                ax.set_title(f"Prediction interval: calibration vs sharpness (target={int(cfg.gp_ci*100)}% )")
                ax.grid(True, axis="y", alpha=0.25)

                # Combined legend
                handles = [b1, b2]
                labels_ = ["Empirical coverage", "Avg interval width (cycles)"]
                ax.legend(handles, labels_, loc="best")
                fig.tight_layout()
                fig.savefig(outdir / "gp_interval_comparison.png", dpi=160)

                if esrel_bw_dir is not None:
                    fig.savefig(esrel_bw_dir / "fig5_interval_comparison.png", dpi=300)
                plt.close(fig)
            except Exception as e:
                print(f"[demo] GP interval comparison plot skipped: {e}")

    print("\nSaved:")
    print(f"- {failure_csv}")
    print(f"- {degr_csv}")
    print(f"- {summary_csv}")
    print(f"- {gp_csv}")
    if (outdir / "dpmm_mode_recovery.csv").exists():
        print(f"- {outdir / 'dpmm_mode_recovery.csv'}")
        print(f"- {outdir / 'dpmm_contingency_true_vs_hat.csv'}")
    if (outdir / "gp_rul_coverage_summary.csv").exists():
        print(f"- {outdir / 'gp_rul_coverage_summary.csv'}")
        print(f"- {outdir / 'gp_rul_coverage_by_unit.csv'}")


if __name__ == "__main__":
    main()
