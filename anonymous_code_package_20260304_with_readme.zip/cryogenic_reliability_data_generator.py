"""Cryogenic equipment failure + degradation data generator.

This module provides physics-inspired simulated datasets tailored for ESREL-style
reliability studies under small-sample, multi-modal failure settings.

It generates two datasets:
1) Failure-time table with right-censoring and heterogeneous covariates.
2) Degradation time-series per unit with temperature/reuse covariates and
   crack-growth-inspired indicators.

The generator is intentionally lightweight (NumPy/Pandas only).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


class CryogenicEquipmentDataGenerator:
    """Simulate cryogenic failure and degradation data for reusable equipment."""

    def __init__(
        self,
        random_seed: int = 42,
        *,
        temp_mean_c: float = -162.0,
        temp_std_c: float = 5.0,
        censor_frac: float = 0.15,
        failure_time_noise_std: float = 2.0,
        degradation_noise_std: float = 2.0,
    ):
        np.random.seed(int(random_seed))

        # Default distribution/measurement controls (used for sensitivity analysis)
        self.temp_mean_c = float(temp_mean_c)
        self.temp_std_c = float(temp_std_c)
        self.censor_frac = float(censor_frac)
        self.failure_time_noise_std = float(failure_time_noise_std)
        self.degradation_noise_std = float(degradation_noise_std)

        # Physics constants / thresholds (used for interpretable covariates)
        self.R_gas = 8.314  # J/(mol*K)
        self.T_ref_C = -162.0
        self.T_ref_K = self.T_ref_C + 273.15
        self.DBTT_C = -120.0  # ductile-to-brittle transition temperature (proxy)
        self.crack_crit = 5.0  # crack length threshold

        # Failure modes (mixture components)
        self.failure_modes = {
            0: {
                "name": "Cryogenic weld fatigue",
                "probability": 0.40,
                "mean_cycles": 45,
                "std_cycles": 8,
                "temp_sensitivity": 0.8,
                "stress_factor": 1.2,
                "paris_C": 1.0e-4,
                "paris_m": 3.0,
                "Ea_Jmol": 3.0e4,
            },
            1: {
                "name": "Seal aging",
                "probability": 0.30,
                "mean_cycles": 35,
                "std_cycles": 6,
                "temp_sensitivity": 1.5,
                "stress_factor": 0.9,
                "paris_C": 0.5e-4,
                "paris_m": 2.5,
                "Ea_Jmol": 6.0e4,
            },
            2: {
                "name": "Low-temperature brittle fracture",
                "probability": 0.20,
                "mean_cycles": 25,
                "std_cycles": 5,
                "temp_sensitivity": 2.0,
                "stress_factor": 1.5,
                "paris_C": 2.0e-4,
                "paris_m": 3.5,
                "Ea_Jmol": 2.0e4,
            },
            3: {
                "name": "Valve mechanical wear",
                "probability": 0.10,
                "mean_cycles": 55,
                "std_cycles": 10,
                "temp_sensitivity": 0.3,
                "stress_factor": 0.7,
                "paris_C": 0.8e-4,
                "paris_m": 2.8,
                "Ea_Jmol": 4.0e4,
            },
        }

    def _arrhenius_factor(self, temperature_c: float, Ea_Jmol: float) -> float:
        """Arrhenius-like relative rate factor normalized at T_ref."""
        T_k = float(temperature_c) + 273.15
        T_k = max(1.0, T_k)
        return float(np.exp((-Ea_Jmol / self.R_gas) * (1.0 / T_k - 1.0 / self.T_ref_K)))

    def _brittleness_factor(self, temperature_c: float) -> float:
        """Simple brittleness multiplier below DBTT."""
        if float(temperature_c) >= self.DBTT_C:
            return 1.0
        delta = min(80.0, self.DBTT_C - float(temperature_c))
        return float(1.0 + 0.01 * delta)

    def generate_failure_data(
        self,
        n_samples: int = 200,
        include_censored: bool = True,
        *,
        temp_mean_c: float | None = None,
        temp_std_c: float | None = None,
        censor_frac: float | None = None,
        failure_time_noise_std: float | None = None,
    ) -> pd.DataFrame:
        """Generate tabular failure-time data with covariates and right-censoring."""
        data = []
        mode_probs = np.array([m["probability"] for m in self.failure_modes.values()], dtype=float)
        mode_probs = mode_probs / mode_probs.sum()

        t_mean = float(self.temp_mean_c if temp_mean_c is None else temp_mean_c)
        t_std = float(self.temp_std_c if temp_std_c is None else temp_std_c)
        cfrac = float(self.censor_frac if censor_frac is None else censor_frac)
        cfrac = float(np.clip(cfrac, 0.0, 0.95))
        ft_noise = float(self.failure_time_noise_std if failure_time_noise_std is None else failure_time_noise_std)

        n_per_mode = np.random.multinomial(int(n_samples), mode_probs)

        for mode_id, n_mode in enumerate(n_per_mode):
            mode_params = self.failure_modes[int(mode_id)]

            for _ in range(int(n_mode)):
                temperature = float(np.random.normal(t_mean, t_std))
                stress_level = float(np.random.uniform(0.6, 1.0))
                reuse_count = int(
                    np.random.choice([0, 1, 2, 3, 4, 5], p=[0.10, 0.20, 0.25, 0.20, 0.15, 0.10])
                )
                cycle_count = max(1, int(np.random.normal(mode_params["mean_cycles"], mode_params["std_cycles"])))

                arrhenius = self._arrhenius_factor(temperature, mode_params["Ea_Jmol"])
                brittle = self._brittleness_factor(temperature)
                temp_effect_linear = 1 + mode_params["temp_sensitivity"] * (temperature - self.T_ref_C) / 100.0
                stress_effect = mode_params["stress_factor"] * stress_level
                reuse_effect = 1.0 + 0.06 * reuse_count

                deltaK = 10.0 * stress_level
                crack_growth_per_cycle = mode_params["paris_C"] * (deltaK ** mode_params["paris_m"])
                crack_init = 0.2 * np.random.rand()
                crack_length = crack_init + crack_growth_per_cycle * cycle_count

                risk_multiplier = arrhenius * brittle * stress_effect * reuse_effect
                time_to_failure = cycle_count * temp_effect_linear * risk_multiplier

                # brittle fracture: occasional early failure
                if int(mode_id) == 2:
                    if crack_length >= self.crack_crit or temperature < (self.DBTT_C - 30):
                        time_to_failure *= float(np.random.uniform(0.3, 0.7))

                time_to_failure = max(1.0, float(time_to_failure + np.random.normal(0, ft_noise)))

                vibration = float(np.random.normal(50 + mode_id * 10, 5))
                pressure_drop = float(np.random.exponential(0.1 * (mode_id + 1)))
                energy_consumed = float(np.random.normal(100 + cycle_count * 0.5, 10))

                data.append(
                    {
                        "sample_id": len(data),
                        "true_mode": int(mode_id),
                        "mode_name": mode_params["name"],
                        "temperature": temperature,
                        "temperature_K": temperature + 273.15,
                        "inv_temperature": 1.0 / max(1.0, temperature + 273.15),
                        "stress_level": stress_level,
                        "reuse_count": reuse_count,
                        "cycle_count": cycle_count,
                        "time_to_failure": time_to_failure,
                        "vibration": vibration,
                        "pressure_drop": pressure_drop,
                        "crack_length": float(crack_length),
                        "arrhenius_factor": float(arrhenius),
                        "brittleness_factor": float(brittle),
                        "energy_consumed": energy_consumed,
                        "is_censored": False,
                    }
                )

        if include_censored:
            n_censored = int(round(int(n_samples) * float(cfrac)))
            if n_censored <= 0 and cfrac > 0:
                n_censored = 1
            for _ in range(int(n_censored)):
                mode_id = int(np.random.choice(4, p=mode_probs))
                mode_params = self.failure_modes[mode_id]

                temperature = float(np.random.normal(t_mean, t_std))
                stress_level = float(np.random.uniform(0.4, 0.7))
                reuse_count = int(
                    np.random.choice([0, 1, 2, 3, 4, 5], p=[0.05, 0.15, 0.25, 0.25, 0.20, 0.10])
                )
                cycle_count = int(np.random.randint(60, 80))

                arrhenius = self._arrhenius_factor(temperature, mode_params["Ea_Jmol"])
                brittle = self._brittleness_factor(temperature)

                data.append(
                    {
                        "sample_id": len(data),
                        "true_mode": mode_id,
                        "mode_name": mode_params["name"],
                        "temperature": temperature,
                        "temperature_K": temperature + 273.15,
                        "inv_temperature": 1.0 / max(1.0, temperature + 273.15),
                        "stress_level": stress_level,
                        "reuse_count": reuse_count,
                        "cycle_count": cycle_count,
                        "time_to_failure": float(cycle_count * 1.2),
                        "vibration": float(np.random.normal(50 + mode_id * 10, 5)),
                        "pressure_drop": float(np.random.exponential(0.1 * (mode_id + 1))),
                        "crack_length": 0.0,
                        "arrhenius_factor": float(arrhenius),
                        "brittleness_factor": float(brittle),
                        "energy_consumed": float(np.random.normal(100 + cycle_count * 0.5, 10)),
                        "is_censored": True,
                    }
                )

        return pd.DataFrame(data)

    def generate_degradation_data(
        self,
        n_equipment: int = 20,
        max_cycles: int = 50,
        include_crack_failure: bool = True,
        *,
        temp_mean_c: float | None = None,
        temp_std_c: float | None = None,
        degradation_noise_std: float | None = None,
    ) -> pd.DataFrame:
        """Generate degradation time-series per equipment unit.

        By default, the simulated unit is considered failed when either
        (1) performance drops below 20.0, or (2) crack length exceeds `crack_crit`.

        If `include_crack_failure=False`, failure is defined only by performance.
        This is useful when validating models that predict RUL from a single
        health indicator (performance) without explicitly modeling crack growth.
        """
        data = []
        mode_probs = np.array([m["probability"] for m in self.failure_modes.values()], dtype=float)
        mode_probs = mode_probs / mode_probs.sum()

        for equip_id in range(int(n_equipment)):
            mode_id = int(np.random.choice(4, p=mode_probs))
            mode_params = self.failure_modes[mode_id]

            t_mean = float(self.temp_mean_c if temp_mean_c is None else temp_mean_c)
            t_std = float(self.temp_std_c if temp_std_c is None else temp_std_c)
            noise_std = float(self.degradation_noise_std if degradation_noise_std is None else degradation_noise_std)

            temperature = float(np.random.normal(t_mean, t_std))
            reuse_count = int(
                np.random.choice([0, 1, 2, 3, 4, 5], p=[0.10, 0.20, 0.25, 0.20, 0.15, 0.10])
            )
            arrhenius = self._arrhenius_factor(temperature, mode_params["Ea_Jmol"])
            brittle = self._brittleness_factor(temperature)

            performance = 100.0
            crack_length = float(0.2 * np.random.rand())

            base_rate = float(np.random.uniform(0.5 + mode_id * 0.3, 1.0 + mode_id * 0.5))
            reuse_effect = 1.0 + 0.05 * reuse_count
            degradation_rate = base_rate * arrhenius * brittle * reuse_effect

            for cycle in range(int(max_cycles)):
                stress_level = float(np.random.uniform(0.6, 1.0))
                deltaK = 10.0 * stress_level
                crack_growth = mode_params["paris_C"] * (deltaK ** mode_params["paris_m"])
                crack_length += float(crack_growth)

                performance -= float(degradation_rate * (1 + cycle * 0.02))
                if mode_id in (0, 2):
                    performance -= float(0.8 * crack_growth * 10)

                performance += float(np.random.normal(0, noise_std))
                performance = float(max(0.0, performance))

                failed = bool(performance < 20.0)
                if bool(include_crack_failure):
                    failed = bool(failed or (crack_length >= self.crack_crit))
                failure_cycle = int(cycle) if failed else None

                data.append(
                    {
                        "equipment_id": int(equip_id),
                        "cycle": int(cycle),
                        "true_mode": int(mode_id),
                        "mode_name": mode_params["name"],
                        "temperature": temperature,
                        "temperature_K": temperature + 273.15,
                        "inv_temperature": 1.0 / max(1.0, temperature + 273.15),
                        "reuse_count": int(reuse_count),
                        "performance": float(performance),
                        "degradation_rate": float(degradation_rate),
                        "arrhenius_factor": float(arrhenius),
                        "brittleness_factor": float(brittle),
                        "stress_level": float(stress_level),
                        "crack_length": float(crack_length),
                        "failed": bool(failed),
                        "failure_cycle": failure_cycle,
                    }
                )

                if failed:
                    break

        return pd.DataFrame(data)

    def visualize_data(self, failure_df: pd.DataFrame, save_path: str = "cryogenic_data_visualization.png") -> None:
        """Optional: quick visualization for sanity-checking simulated failure data."""
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except Exception as e:
            print(f"[generator] matplotlib unavailable, skip plots: {e}")
            return

        fig, axes = plt.subplots(2, 3, figsize=(18, 10))

        ax = axes[0, 0]
        mode_counts = failure_df[~failure_df["is_censored"]]["true_mode"].value_counts().sort_index()
        mode_names = [self.failure_modes[i]["name"] for i in mode_counts.index]
        ax.bar(range(len(mode_counts)), mode_counts.values, color="steelblue", alpha=0.7)
        ax.set_xticks(range(len(mode_counts)))
        ax.set_xticklabels(mode_names, rotation=30, ha="right")
        ax.set_ylabel("Count")
        ax.set_title("Failure Mode Distribution")
        ax.grid(True, alpha=0.3, axis="y")

        ax = axes[0, 1]
        for mode_id in range(4):
            md = failure_df[(failure_df["true_mode"] == mode_id) & (~failure_df["is_censored"])]
            if len(md) > 0:
                ax.hist(md["time_to_failure"], bins=15, alpha=0.5, label=self.failure_modes[mode_id]["name"])
        ax.set_xlabel("Time to Failure")
        ax.set_ylabel("Frequency")
        ax.set_title("Failure Time by Mode")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.3)

        ax = axes[0, 2]
        for mode_id in range(4):
            md = failure_df[(failure_df["true_mode"] == mode_id) & (~failure_df["is_censored"])]
            if len(md) > 0:
                ax.scatter(md["temperature"], md["time_to_failure"], s=20, alpha=0.6, label=f"mode {mode_id}")
        ax.set_xlabel("Temperature (°C)")
        ax.set_ylabel("Time to Failure")
        ax.set_title("Temperature vs Failure Time")
        ax.grid(True, alpha=0.3)

        ax = axes[1, 0]
        ax.scatter(failure_df["stress_level"], failure_df["time_to_failure"], s=18, alpha=0.5)
        ax.set_xlabel("Stress level")
        ax.set_ylabel("Time to Failure")
        ax.set_title("Stress vs Failure Time")
        ax.grid(True, alpha=0.3)

        ax = axes[1, 1]
        ax.scatter(failure_df["vibration"], failure_df["pressure_drop"], s=18, alpha=0.5)
        ax.set_xlabel("Vibration")
        ax.set_ylabel("Pressure drop")
        ax.set_title("Feature space")
        ax.grid(True, alpha=0.3)

        axes[1, 2].axis("off")
        plt.suptitle("Cryogenic failure data (simulated)", fontsize=14, fontweight="bold")
        plt.tight_layout()
        plt.savefig(save_path, dpi=160, bbox_inches="tight")
        plt.close(fig)
